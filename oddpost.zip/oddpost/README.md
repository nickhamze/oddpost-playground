# Oddpost

Oddpost is OpenStation's writing desk for beautiful, one-off personal correspondence. It is deliberately not a campaign manager, inbox client, CRM, audience database, or analytics product.

## What is built

- A native OpenStation window and wallpaper icon; there is no separate WordPress admin screen.
- A React Email/Tiptap composer with slash commands for headings, images, buttons, dividers, sections, and columns.
- Eight curated stationery systems, including Air Mail, Typewritten, and After Dark.
- Per-block design controls, desktop/mobile/plain-text previews, hidden preheaders, and practical preflight checks.
- User-owned, revisioned drafts and sent copies stored privately in WordPress.
- WordPress Media Library uploads for inline images and attachments.
- A per-OpenStation-user sending identity, encrypted with AES-256-GCM at rest.
- WordPress mail, Gmail, iCloud Mail, Fastmail, Zoho Mail, and guarded custom SMTP connections.
- Provider-accepted send status only. Oddpost adds no tracking pixels, open tracking, click tracking, lists, campaigns, or unsubscribe machinery.

Replies go to the user's normal inbox. Oddpost never requests inbox access.

## OpenStation coupling

Oddpost declares `Requires Plugins: desktop-mode` and uses OpenStation's native window registry, desktop icon registry, lazy bundle config, tracked `wp.desktop.fetch`, confirmation dialog, notification system, window lifecycle/abort signal, palette tokens, and `wpd-button`/`wpd-notice` components. The legacy `wp.os` API alias remains supported for older OpenStation builds. Identity and media come from the current WordPress/OpenStation user.

## Development

```sh
npm install
npm run check
npm run package
```

The installable artifact is written to `release/oddpost-0.2.0.zip`.

## Sending notes

- Gmail, iCloud, Fastmail, and most hosted email providers require an app-specific password for SMTP.
- Custom SMTP accepts public DNS hostnames only and rejects private/reserved address resolution before connecting.
- “Sent” means the configured provider accepted the message. It does not prove inbox delivery.
- For images to appear to a recipient, Media Library URLs must be publicly reachable over HTTPS.
