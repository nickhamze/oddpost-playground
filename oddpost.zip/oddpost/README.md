# ODD Post

ODD Post is OpenStation's writing desk for beautiful, one-off personal correspondence. It is deliberately not a campaign manager, inbox client, CRM, audience database, or analytics product.

## What is built

- A native OpenStation window and wallpaper icon; there is no separate WordPress admin screen.
- A React Email/Tiptap composer with slash commands for headings, images, buttons, dividers, sections, and columns.
- Eleven curated stationery systems, including Air Mail, Museum Letterhead, Pressed Herbarium, Celebration Ribbon, and After Dark.
- Per-block design controls, desktop/mobile/plain-text previews, hidden preheaders, and practical preflight checks, all using the same server-prepared artifact that is handed to the mailer.
- User-owned, revisioned drafts and sent copies stored privately in WordPress.
- WordPress Media Library uploads for inline images and attachments.
- A per-OpenStation-user sending identity, encrypted with AES-256-GCM at rest. WordPress mail is restricted to the current user's email unless a site-level filter explicitly adds another identity.
- WordPress mail, Gmail, iCloud Mail, Fastmail, and Zoho Mail. Custom SMTP is hidden and disabled by default; a code-level filter may enable it without discarding previously saved settings.
- A dedicated Administrator-default `oddpost_send_mail` capability, durable idempotency records, and atomic per-user/site safety limits. Authors without the capability may still write, save, and preview drafts.
- Provider-accepted send status only. ODD Post adds no tracking pixels, open tracking, click tracking, lists, campaigns, or unsubscribe machinery.

Replies go to the user's normal inbox. ODD Post never requests inbox access.

## OpenStation coupling

ODD Post declares `Requires Plugins: desktop-mode` and uses OpenStation's native window registry, desktop icon registry, lazy bundle config, tracked `wp.desktop.fetch`, confirmation dialog, notification system, window lifecycle/abort signal, palette tokens, and `wpd-button`/`wpd-notice` components. The legacy `wp.os` API alias remains supported for older OpenStation builds. Identity and media come from the current WordPress/OpenStation user.

## Development

```sh
npm install
npm run check
npm run package
```

The installable artifact is written to `release/oddpost-0.2.1.zip`.

## Sending notes

- Gmail, iCloud, Fastmail, and most hosted email providers require an app-specific password for SMTP.
- SMTP connections resolve and validate public DNS once, connect to that vetted address, and retain the original hostname for TLS certificate verification.
- “Sent” means the configured provider accepted the message. It does not prove inbox delivery.
- If provider acceptance cannot be confirmed, ODD Post does not retry automatically. Sending a new copy requires an explicit duplicate-risk confirmation.
- For images to appear to a recipient, Media Library URLs must be publicly reachable over HTTPS.
