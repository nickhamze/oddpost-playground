<?php
/**
 * Build the single server-authoritative artifact used for preview and delivery.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_Message_Preparer {
	const MAX_TEXT_BYTES       = 262144;
	const MAX_SUBJECT_BYTES    = 998;
	const MAX_PREHEADER_LENGTH = 160;
	const MAX_ATTACHMENTS      = 10;
	const MAX_ATTACHMENT_BYTES = 10485760;
	const MAX_ATTACHMENTS_BYTES = 20971520;

	/** @var Oddpost_Store */
	private $store;

	public function __construct( $store ) {
		$this->store = $store;
	}

	/**
	 * Prepare and validate one immutable mail artifact.
	 *
	 * @param array $input Message input.
	 * @param int   $user_id Current user ID.
	 * @return array|WP_Error
	 */
	public function prepare( $input, $user_id ) {
		$to = $this->validate_addresses( isset( $input['to'] ) ? $input['to'] : array(), true );
		if ( is_wp_error( $to ) ) {
			return $to;
		}
		$cc = $this->validate_addresses( isset( $input['cc'] ) ? $input['cc'] : array(), false );
		if ( is_wp_error( $cc ) ) {
			return $cc;
		}
		$bcc = $this->validate_addresses( isset( $input['bcc'] ) ? $input['bcc'] : array(), false );
		if ( is_wp_error( $bcc ) ) {
			return $bcc;
		}
		$all = array_merge( $to, $cc, $bcc );
		if ( count( array_unique( $all ) ) !== count( $all ) ) {
			return new WP_Error( 'oddpost_recipients_duplicate', __( 'Each recipient may appear only once across To, Cc, and Bcc.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( count( $all ) > Oddpost_Store::MAX_RECIPIENTS ) {
			return new WP_Error( 'oddpost_recipients_invalid', __( 'Add at least one recipient, with no more than 20 people total.', 'oddpost' ), array( 'status' => 400 ) );
		}

		$subject = $this->clean_single_line( isset( $input['subject'] ) ? $input['subject'] : '' );
		if ( '' === $subject ) {
			return new WP_Error( 'oddpost_subject_missing', __( 'Add a subject before previewing or sending.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( strlen( $subject ) > self::MAX_SUBJECT_BYTES ) {
			return new WP_Error( 'oddpost_subject_too_large', __( 'Shorten the subject before previewing or sending.', 'oddpost' ), array( 'status' => 413 ) );
		}

		$raw_html = isset( $input['html'] ) ? wp_check_invalid_utf8( (string) $input['html'] ) : '';
		if ( '' === $raw_html || strlen( $raw_html ) > Oddpost_Store::MAX_HTML_BYTES ) {
			return new WP_Error( 'oddpost_message_too_large', __( 'The HTML version is empty or too large to send safely.', 'oddpost' ), array( 'status' => 413 ) );
		}
		$text = $this->clean_plain_text( isset( $input['text'] ) ? $input['text'] : '' );
		if ( is_wp_error( $text ) ) {
			return $text;
		}
		$preheader = $this->clean_single_line( isset( $input['preheader'] ) ? $input['preheader'] : '' );
		$preheader_length = function_exists( 'mb_strlen' ) ? mb_strlen( $preheader, 'UTF-8' ) : strlen( $preheader );
		if ( $preheader_length > self::MAX_PREHEADER_LENGTH ) {
			return new WP_Error( 'oddpost_preheader_too_large', __( 'Keep the inbox preview to 160 characters or fewer.', 'oddpost' ), array( 'status' => 413 ) );
		}

		$html = $this->prepare_html( $raw_html, $preheader );
		if ( '' === trim( wp_strip_all_tags( $html ) ) || strlen( $html ) > Oddpost_Store::MAX_HTML_BYTES ) {
			return new WP_Error( 'oddpost_message_invalid', __( 'The letter did not contain safe, readable HTML.', 'oddpost' ), array( 'status' => 400 ) );
		}
		$text = $this->append_image_alts( $text, $html );
		if ( strlen( $text ) > self::MAX_TEXT_BYTES ) {
			return new WP_Error( 'oddpost_text_too_large', __( 'The plain-text version is too large to send safely.', 'oddpost' ), array( 'status' => 413 ) );
		}
		if ( '' === trim( $text ) ) {
			return new WP_Error( 'oddpost_message_incomplete', __( 'Add plain-text content before previewing or sending.', 'oddpost' ), array( 'status' => 400 ) );
		}

		$attachments = $this->validate_attachments( isset( $input['attachments'] ) ? $input['attachments'] : array(), $user_id );
		if ( is_wp_error( $attachments ) ) {
			return $attachments;
		}

		$canonical = array(
			'to'            => $to,
			'cc'            => $cc,
			'bcc'           => $bcc,
			'subject'       => $subject,
			'html'          => $html,
			'text'          => $text,
			'attachmentIds' => $attachments['ids'],
			'attachmentManifest' => $attachments['manifest'],
		);
		$canonical['artifactHash']   = hash( 'sha256', wp_json_encode( $canonical, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
		$canonical['attachmentPaths'] = $attachments['paths'];
		return $canonical;
	}

	/**
	 * Resolve every requested attachment without silently dropping failures.
	 *
	 * @param mixed $value Requested attachment IDs.
	 * @param int   $user_id Current user ID.
	 * @return array|WP_Error
	 */
	public function validate_attachments( $value, $user_id ) {
		$requested = is_array( $value ) ? array_values( $value ) : array();
		if ( count( $requested ) > self::MAX_ATTACHMENTS ) {
			return new WP_Error( 'oddpost_attachments_too_many', __( 'Attach no more than 10 files.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( empty( $requested ) ) {
			return array( 'ids' => array(), 'paths' => array(), 'manifest' => array() );
		}
		$uploads = wp_upload_dir();
		$base    = empty( $uploads['basedir'] ) ? false : realpath( $uploads['basedir'] );
		if ( false === $base && ! empty( $requested ) ) {
			return new WP_Error( 'oddpost_attachment_unavailable', __( 'The uploads folder is unavailable.', 'oddpost' ), array( 'status' => 400 ) );
		}

		$allowed_mimes = array_values( get_allowed_mime_types() );
		$ids           = array();
		$paths         = array();
		$manifest      = array();
		$total         = 0;
		foreach ( $requested as $raw_id ) {
			if ( ! is_numeric( $raw_id ) || (int) $raw_id < 1 ) {
				return new WP_Error( 'oddpost_attachment_invalid', __( 'One of the requested attachments is invalid.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$attachment_id = (int) $raw_id;
			if ( in_array( $attachment_id, $ids, true ) ) {
				continue;
			}
			$post = get_post( $attachment_id );
			if ( ! $post || 'attachment' !== $post->post_type || (int) $post->post_author !== (int) $user_id ) {
				return new WP_Error( 'oddpost_attachment_forbidden', __( 'Every attachment must belong to your OpenStation user.', 'oddpost' ), array( 'status' => 403 ) );
			}
			$stored_mime = (string) get_post_mime_type( $attachment_id );
			if ( ! in_array( $stored_mime, $allowed_mimes, true ) ) {
				return new WP_Error( 'oddpost_attachment_type', __( 'One attachment has a file type WordPress does not allow.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$path = get_attached_file( $attachment_id );
			$real = is_string( $path ) ? realpath( $path ) : false;
			if ( false === $real || false === $base || ( $real !== $base && 0 !== strpos( $real, $base . DIRECTORY_SEPARATOR ) ) || ! is_file( $real ) || ! is_readable( $real ) ) {
				return new WP_Error( 'oddpost_attachment_unavailable', __( 'One attachment is missing or cannot be read safely.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$filetype = wp_check_filetype( basename( $real ), get_allowed_mime_types() );
			if ( empty( $filetype['type'] ) || $filetype['type'] !== $stored_mime ) {
				return new WP_Error( 'oddpost_attachment_type', __( 'One attachment does not match its allowed file type.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$size = filesize( $real );
			if ( false === $size || $size > self::MAX_ATTACHMENT_BYTES ) {
				return new WP_Error( 'oddpost_attachment_too_large', __( 'Each attachment must be 10 MB or smaller.', 'oddpost' ), array( 'status' => 413 ) );
			}
			$total += $size;
			if ( $total > self::MAX_ATTACHMENTS_BYTES ) {
				return new WP_Error( 'oddpost_attachments_too_large', __( 'Attachments must total 20 MB or less.', 'oddpost' ), array( 'status' => 413 ) );
			}
			$digest = hash_file( 'sha256', $real );
			if ( ! is_string( $digest ) || ! preg_match( '/^[a-f0-9]{64}$/', $digest ) ) {
				return new WP_Error( 'oddpost_attachment_unavailable', __( 'One attachment could not be read completely and was not added.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$ids[]      = $attachment_id;
			$paths[]    = $real;
			$manifest[] = array(
				'id'     => $attachment_id,
				'name'   => basename( $real ),
				'mime'   => $stored_mime,
				'size'   => (int) $size,
				'sha256' => $digest,
			);
		}
		return array( 'ids' => $ids, 'paths' => $paths, 'manifest' => $manifest );
	}

	/** @return array|WP_Error */
	private function validate_addresses( $value, $required ) {
		$input = is_array( $value ) ? $value : preg_split( '/[,;\n]+/', (string) $value );
		$valid = array();
		foreach ( $input as $raw ) {
			$raw_address = trim( (string) $raw );
			if ( '' === $raw_address ) {
				continue;
			}
			$address = sanitize_email( $raw_address );
			if ( '' === $address || 0 !== strcasecmp( $raw_address, $address ) || ! is_email( $address ) ) {
				return new WP_Error( 'oddpost_recipients_invalid', __( 'Check every recipient address before continuing.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$valid[] = strtolower( $address );
		}
		if ( count( array_unique( $valid ) ) !== count( $valid ) ) {
			return new WP_Error( 'oddpost_recipients_duplicate', __( 'Each recipient may appear only once across To, Cc, and Bcc.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( ( $required && empty( $valid ) ) || count( $valid ) > Oddpost_Store::MAX_RECIPIENTS ) {
			return new WP_Error( 'oddpost_recipients_invalid', __( 'Add at least one recipient, with no more than 20 people total.', 'oddpost' ), array( 'status' => 400 ) );
		}
		return $valid;
	}

	/** @return string */
	private function clean_single_line( $value ) {
		$value = wp_check_invalid_utf8( (string) $value );
		$value = wp_strip_all_tags( $value, true );
		$value = preg_replace( '/[\x00-\x1F\x7F]+/u', ' ', $value );
		return trim( preg_replace( '/\s+/u', ' ', (string) $value ) );
	}

	/** @return string|WP_Error */
	private function clean_plain_text( $value ) {
		$text = wp_check_invalid_utf8( (string) $value );
		$text = str_replace( array( "\r\n", "\r" ), "\n", $text );
		$text = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text );
		// React Email's plain-text serializer can place NBSP + zero-width joiner
		// runs around inline code spacing. Remove only that known compound artifact
		// so intentional prose NBSPs and emoji ZWJ sequences remain untouched.
		$text = preg_replace( '/\x{00A0}[\x{200B}\x{200C}\x{200D}\x{FEFF}]+/u', ' ', $text );
		if ( strlen( $text ) > self::MAX_TEXT_BYTES ) {
			return new WP_Error( 'oddpost_text_too_large', __( 'The plain-text version is too large to send safely.', 'oddpost' ), array( 'status' => 413 ) );
		}
		return trim( $text );
	}

	/** @return string */
	private function append_image_alts( $text, $html ) {
		if ( ! preg_match_all( '/<img\b[^>]*\balt=(?:"([^"]*)"|\'([^\']*)\')[^>]*>/i', $html, $matches, PREG_SET_ORDER ) ) {
			return $text;
		}
		foreach ( $matches as $match ) {
			$encoded = isset( $match[1] ) && '' !== $match[1] ? $match[1] : $match[2];
			$alt     = trim( html_entity_decode( $encoded, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			$contains_alt = function_exists( 'mb_stripos' ) ? false !== mb_stripos( $text, $alt, 0, 'UTF-8' ) : false !== stripos( $text, $alt );
			if ( '' !== $alt && ! $contains_alt ) {
				$text .= "\n\n[Image: " . $alt . ']';
			}
		}
		return trim( $text );
	}

	/** @return string */
	private function prepare_html( $raw_html, $preheader ) {
		$body_style = '';
		if ( preg_match( '/<body\b[^>]*\bstyle=(?:"([^"]*)"|\'([^\']*)\')[^>]*>/i', $raw_html, $style_match ) ) {
			$body_style = isset( $style_match[1] ) && '' !== $style_match[1] ? $style_match[1] : $style_match[2];
		}
		$body = preg_match( '/<body\b[^>]*>([\s\S]*)<\/body>/i', $raw_html, $body_match ) ? $body_match[1] : $raw_html;
		$body = preg_replace( '/<!--[\s\S]*?-->/', '', $body );
		$body = preg_replace( '/<style\b[^>]*>[\s\S]*?<\/style>/i', '', $body );

		$style_filter = array( $this, 'allow_email_css' );
		add_filter( 'safe_style_css', $style_filter );
		try {
			$body_style = safecss_filter_attr( $body_style );
			$body       = $this->store->sanitize_email_html( $body );
		} finally {
			remove_filter( 'safe_style_css', $style_filter );
		}

		$body = preg_replace_callback( '/<img\b([^>]*)>/i', array( $this, 'make_image_fluid' ), $body );
		$body = preg_replace_callback( '/<td\b([^>]*)>/i', array( $this, 'make_cell_wrap' ), $body );
		$body = preg_replace_callback( '/<table\b([^>]*\bmax-width\s*:\s*600px[^>]*)>/i', array( $this, 'add_outlook_width' ), $body );
		$hidden = '';
		if ( '' !== $preheader ) {
			$hidden = '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;mso-hide:all">' . esc_html( $preheader ) . '&#847;&zwnj;&nbsp;&#8199;&#65279;&nbsp;</div>';
		}
		$head_css = 'img{max-width:100%;height:auto}table{max-width:100%}td{overflow-wrap:anywhere;word-break:break-word}@media only screen and (max-width:600px){table[role="presentation"]{width:100%!important;max-width:100%!important}td[data-id="__react-email-column"]{display:block!important;width:100%!important}td{max-width:100%!important;padding-left:16px!important;padding-right:16px!important}}';
		return '<!doctype html><html dir="ltr" lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="x-apple-disable-message-reformatting"><meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no"><style type="text/css">' . $head_css . '</style></head><body dir="ltr" lang="en" style="margin:0;padding:0;' . esc_attr( $body_style ) . '">' . $hidden . $body . '</body></html>';
	}

	/** @return array */
	public function allow_email_css( $styles ) {
		return array_values( array_unique( array_merge( $styles, array( 'box-shadow', 'max-height', 'max-width', 'min-width', 'opacity', 'overflow-wrap', 'word-break', 'mso-hide', 'mso-padding-alt', 'mso-text-raise' ) ) ) );
	}

	/** @return string */
	private function make_image_fluid( $match ) {
		$max_width = '100%';
		if ( preg_match( '/\bwidth\s*=\s*(?:"([0-9]+)"|\'([0-9]+)\'|([0-9]+))/i', $match[1], $width_match ) ) {
			$authored_width = 0;
			foreach ( array_slice( $width_match, 1 ) as $width ) {
				if ( '' !== $width ) {
					$authored_width = (int) $width;
					break;
				}
			}
			if ( $authored_width > 0 && $authored_width < 600 ) {
				$max_width = $authored_width . 'px';
			}
		}
		return $this->append_style( 'img', $match[1], 'width:100%;height:auto;max-width:' . $max_width );
	}

	/** @return string */
	private function make_cell_wrap( $match ) {
		return $this->append_style( 'td', $match[1], 'overflow-wrap:anywhere;word-break:break-word' );
	}

	/** Give Word-rendering Outlook a fixed attribute while modern clients keep inline fluid CSS. */
	private function add_outlook_width( $match ) {
		$attributes = $match[1];
		if ( preg_match( '/\bwidth=("|\')[^"\']*\1/i', $attributes ) ) {
			$attributes = preg_replace( '/\bwidth=("|\')[^"\']*\1/i', 'width="600"', $attributes, 1 );
		} else {
			$attributes .= ' width="600"';
		}
		return '<table' . $attributes . '>';
	}

	/** @return string */
	private function append_style( $tag, $attributes, $css ) {
		if ( preg_match( '/\bstyle=("|\')([^"\']*)\1/i', $attributes, $match ) ) {
			$replacement = 'style=' . $match[1] . rtrim( $match[2], ';' ) . ';' . $css . $match[1];
			$attributes  = preg_replace( '/\bstyle=("|\')([^"\']*)\1/i', $replacement, $attributes, 1 );
		} else {
			$attributes .= ' style="' . $css . '"';
		}
		return '<' . $tag . $attributes . '>';
	}
}
