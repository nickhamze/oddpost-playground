<?php
/**
 * Personal one-off mail delivery via WordPress or authenticated SMTP.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_Mailer {
	/**
	 * Send one message.
	 *
	 * @param array $message Sanitized message.
	 * @param array $connection Connection credentials.
	 * @return true|WP_Error
	 */
	public function send( $message, $connection ) {
		if ( 'wordpress' === $connection['provider'] ) {
			return $this->send_wordpress( $message, $connection );
		}
		return $this->send_smtp( $message, $connection );
	}

	/**
	 * Test a saved SMTP connection without sending a message.
	 *
	 * @param array $connection Connection credentials.
	 * @return true|WP_Error
	 */
	public function test_connection( $connection ) {
		if ( 'wordpress' === $connection['provider'] ) {
			return true;
		}
		$mailer = $this->make_smtp_mailer( $connection );
		if ( is_wp_error( $mailer ) ) {
			return $mailer;
		}
		try {
			if ( ! $mailer->smtpConnect() ) {
				return new WP_Error( 'oddpost_smtp_failed', __( 'Oddpost could not connect to that email account.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$mailer->smtpClose();
			return true;
		} catch ( Exception $error ) {
			return new WP_Error( 'oddpost_smtp_failed', $error->getMessage(), array( 'status' => 400 ) );
		}
	}

	/** @return true|WP_Error */
	private function send_wordpress( $message, $connection ) {
		$alt_body = $message['text'];
		$callback = static function ( $phpmailer ) use ( $alt_body ) {
			$phpmailer->AltBody = $alt_body;
		};
		add_action( 'phpmailer_init', $callback );

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $connection['fromName'] . ' <' . $connection['fromEmail'] . '>',
		);
		if ( ! empty( $connection['replyTo'] ) ) {
			$headers[] = 'Reply-To: ' . $connection['replyTo'];
		}
		foreach ( $message['cc'] as $address ) {
			$headers[] = 'Cc: ' . $address;
		}
		foreach ( $message['bcc'] as $address ) {
			$headers[] = 'Bcc: ' . $address;
		}

		$sent = wp_mail( $message['to'], $message['subject'], $message['html'], $headers, $message['attachmentPaths'] );
		remove_action( 'phpmailer_init', $callback );

		return $sent ? true : new WP_Error( 'oddpost_send_failed', __( 'The WordPress mail service did not accept the message.', 'oddpost' ), array( 'status' => 502 ) );
	}

	/** @return true|WP_Error */
	private function send_smtp( $message, $connection ) {
		$mailer = $this->make_smtp_mailer( $connection );
		if ( is_wp_error( $mailer ) ) {
			return $mailer;
		}
		try {
			$mailer->setFrom( $connection['fromEmail'], $connection['fromName'] );
			if ( ! empty( $connection['replyTo'] ) ) {
				$mailer->addReplyTo( $connection['replyTo'] );
			}
			foreach ( $message['to'] as $address ) {
				$mailer->addAddress( $address );
			}
			foreach ( $message['cc'] as $address ) {
				$mailer->addCC( $address );
			}
			foreach ( $message['bcc'] as $address ) {
				$mailer->addBCC( $address );
			}
			foreach ( $message['attachmentPaths'] as $path ) {
				$mailer->addAttachment( $path );
			}
			$mailer->Subject = $message['subject'];
			$mailer->isHTML( true );
			$mailer->Body    = $message['html'];
			$mailer->AltBody = $message['text'];
			$mailer->send();
			return true;
		} catch ( Exception $error ) {
			return new WP_Error( 'oddpost_send_failed', $error->getMessage(), array( 'status' => 502 ) );
		}
	}

	/** @return PHPMailer\PHPMailer\PHPMailer|WP_Error */
	private function make_smtp_mailer( $connection ) {
		if ( ! class_exists( 'PHPMailer\\PHPMailer\\PHPMailer' ) ) {
			require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
			require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
			require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
		}
		try {
			$mailer           = new PHPMailer\PHPMailer\PHPMailer( true );
			$mailer->CharSet  = get_bloginfo( 'charset' );
			$mailer->Timeout  = 12;
			$mailer->SMTPDebug = 0;
			$mailer->isSMTP();
			$mailer->Host       = $connection['host'];
			$mailer->Port       = (int) $connection['port'];
			$mailer->SMTPAuth   = true;
			$mailer->Username   = $connection['username'];
			$mailer->Password   = $connection['password'];
			$mailer->SMTPSecure = 'ssl' === $connection['secure']
				? PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS
				: PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
			return $mailer;
		} catch ( Exception $error ) {
			return new WP_Error( 'oddpost_mailer_failed', $error->getMessage(), array( 'status' => 500 ) );
		}
	}
}

