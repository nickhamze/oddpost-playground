<?php
/**
 * User-owned drafts and connection settings.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_Store {
	const CONNECTION_META = '_oddpost_connection';
	const MAX_RECIPIENTS   = 20;
	const MAX_HTML_BYTES   = 524288;
	const MAX_ATTACHMENTS  = 10;

	/**
	 * Return a user's draft summaries, newest first.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	public function list_drafts( $user_id ) {
		$posts = get_posts(
			array(
				'post_type'      => 'oddpost_letter',
				'post_status'    => array( 'draft', 'private' ),
				'author'         => $user_id,
				'posts_per_page' => 50,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);

		return array_map( array( $this, 'serialize_summary' ), $posts );
	}

	/**
	 * Load one user-owned draft.
	 *
	 * @param int $post_id Draft ID.
	 * @param int $user_id User ID.
	 * @return array|WP_Error
	 */
	public function get_draft( $post_id, $user_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'oddpost_letter' !== $post->post_type || (int) $post->post_author !== (int) $user_id ) {
			return new WP_Error( 'oddpost_draft_not_found', __( 'That letter was not found.', 'oddpost' ), array( 'status' => 404 ) );
		}

		return $this->serialize_draft( $post );
	}

	/**
	 * Create or update a user-owned draft.
	 *
	 * @param array $data Draft data.
	 * @param int   $user_id User ID.
	 * @return array|WP_Error
	 */
	public function save_draft( $data, $user_id ) {
		$post_id = isset( $data['id'] ) ? absint( $data['id'] ) : 0;
		if ( $post_id ) {
			$existing = get_post( $post_id );
			if ( ! $existing || 'oddpost_letter' !== $existing->post_type || (int) $existing->post_author !== (int) $user_id ) {
				return new WP_Error( 'oddpost_draft_not_found', __( 'That letter was not found.', 'oddpost' ), array( 'status' => 404 ) );
			}
		}

		$subject = sanitize_text_field( isset( $data['subject'] ) ? $data['subject'] : '' );
		$content = isset( $data['content'] ) && is_array( $data['content'] ) ? wp_json_encode( $data['content'] ) : '{}';
		$postarr = array(
			'ID'           => $post_id,
			'post_type'    => 'oddpost_letter',
			'post_status'  => 'draft',
			'post_author'  => $user_id,
			'post_title'   => '' !== $subject ? $subject : __( 'Untitled letter', 'oddpost' ),
			'post_content' => $content,
		);
		$saved   = wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$meta = array(
			'_oddpost_to'         => $this->sanitize_address_list( isset( $data['to'] ) ? $data['to'] : array() ),
			'_oddpost_cc'         => $this->sanitize_address_list( isset( $data['cc'] ) ? $data['cc'] : array() ),
			'_oddpost_bcc'        => $this->sanitize_address_list( isset( $data['bcc'] ) ? $data['bcc'] : array() ),
			'_oddpost_subject'    => $subject,
			'_oddpost_preheader'  => sanitize_text_field( isset( $data['preheader'] ) ? $data['preheader'] : '' ),
			'_oddpost_html'       => $this->sanitize_email_html( isset( $data['html'] ) ? $data['html'] : '' ),
			'_oddpost_text'       => sanitize_textarea_field( isset( $data['text'] ) ? $data['text'] : '' ),
			'_oddpost_stationery' => sanitize_key( isset( $data['stationery'] ) ? $data['stationery'] : 'nice-note' ),
			'_oddpost_attachments'=> $this->sanitize_attachment_ids( isset( $data['attachments'] ) ? $data['attachments'] : array(), $user_id ),
			'_oddpost_status'     => 'draft',
		);
		foreach ( $meta as $key => $value ) {
			update_post_meta( $saved, $key, $value );
		}

		return $this->get_draft( $saved, $user_id );
	}

	/**
	 * Delete a user-owned draft.
	 *
	 * @param int $post_id Draft ID.
	 * @param int $user_id User ID.
	 * @return true|WP_Error
	 */
	public function delete_draft( $post_id, $user_id ) {
		$draft = $this->get_draft( $post_id, $user_id );
		if ( is_wp_error( $draft ) ) {
			return $draft;
		}
		return (bool) wp_delete_post( $post_id, true );
	}

	/**
	 * Get a safe connection summary, with no password.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	public function get_connection_summary( $user_id ) {
		$connection = get_user_meta( $user_id, self::CONNECTION_META, true );
		if ( ! is_array( $connection ) || empty( $connection['provider'] ) ) {
			return array(
				'connected' => false,
				'provider'  => '',
			);
		}
		$has_password = ! empty( $connection['password'] );
		unset( $connection['password'] );
		$connection['connected']   = true;
		$connection['hasPassword'] = 'wordpress' !== $connection['provider'] && $has_password;
		$connection['available']   = 'custom' !== $connection['provider'] || self::custom_smtp_enabled();
		return $connection;
	}

	/**
	 * Return the full connection to trusted server code.
	 *
	 * @param int $user_id User ID.
	 * @return array|WP_Error
	 */
	public function get_connection( $user_id ) {
		$connection = get_user_meta( $user_id, self::CONNECTION_META, true );
		if ( ! is_array( $connection ) || empty( $connection['provider'] ) ) {
			return new WP_Error( 'oddpost_not_connected', __( 'Connect a sending account before sending.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( 'wordpress' === $connection['provider'] ) {
			$from_email = isset( $connection['fromEmail'] ) ? strtolower( (string) $connection['fromEmail'] ) : '';
			if ( ! in_array( $from_email, self::allowed_wordpress_from_addresses( $user_id ), true ) ) {
				return new WP_Error( 'oddpost_from_not_allowed', __( 'WordPress delivery must use an email address allowed for your current user.', 'oddpost' ), array( 'status' => 403 ) );
			}
			return $connection;
		}
		if ( 'custom' === $connection['provider'] && ! self::custom_smtp_enabled() ) {
			return new WP_Error( 'oddpost_custom_smtp_disabled', __( 'Custom SMTP is temporarily unavailable. Your saved settings have not been removed.', 'oddpost' ), array( 'status' => 403 ) );
		}
		if ( 'wordpress' !== $connection['provider'] ) {
			$resolved_host = empty( $connection['host'] ) ? false : self::resolve_safe_smtp_host( $connection['host'] );
			if ( false === $resolved_host ) {
				return new WP_Error( 'oddpost_host_invalid', __( 'The saved SMTP host is no longer resolving to a public address. Reconnect the account.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$password = Oddpost_Crypto::decrypt( isset( $connection['password'] ) ? $connection['password'] : '' );
			if ( is_wp_error( $password ) ) {
				return $password;
			}
			$connection['password'] = $password;
			// PHPMailer connects to this vetted address instead of resolving the
			// hostname a second time. TLS still verifies the original host name.
			$connection['resolvedHost'] = $resolved_host;
		}
		return $connection;
	}

	/**
	 * Save a validated connection.
	 *
	 * @param array $data Connection input.
	 * @param int   $user_id User ID.
	 * @return array|WP_Error
	 */
	public function save_connection( $data, $user_id ) {
		$provider   = sanitize_key( isset( $data['provider'] ) ? $data['provider'] : '' );
		$presets    = self::provider_definitions();
		$connection = array(
			'provider'  => $provider,
			'fromName'  => sanitize_text_field( isset( $data['fromName'] ) ? $data['fromName'] : '' ),
			'fromEmail' => sanitize_email( isset( $data['fromEmail'] ) ? $data['fromEmail'] : '' ),
			'replyTo'   => sanitize_email( isset( $data['replyTo'] ) ? $data['replyTo'] : '' ),
		);

		if ( ! isset( $presets[ $provider ] ) ) {
			return new WP_Error( 'oddpost_provider_invalid', __( 'Choose a supported sending method.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( ! is_email( $connection['fromEmail'] ) ) {
			return new WP_Error( 'oddpost_from_invalid', __( 'Enter a valid From email address.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( 'wordpress' === $provider && ! in_array( strtolower( $connection['fromEmail'] ), self::allowed_wordpress_from_addresses( $user_id ), true ) ) {
			return new WP_Error( 'oddpost_from_not_allowed', __( 'WordPress delivery must use an email address allowed for your current user.', 'oddpost' ), array( 'status' => 403 ) );
		}
		if ( 'custom' === $provider && ! self::custom_smtp_enabled() ) {
			return new WP_Error( 'oddpost_custom_smtp_disabled', __( 'Custom SMTP is temporarily unavailable. Your saved settings have not been removed.', 'oddpost' ), array( 'status' => 403 ) );
		}

		if ( 'wordpress' !== $provider ) {
			$preset = $presets[ $provider ];
			$host   = 'custom' === $provider ? sanitize_text_field( isset( $data['host'] ) ? $data['host'] : '' ) : $preset['host'];
			$port   = 'custom' === $provider ? absint( isset( $data['port'] ) ? $data['port'] : 0 ) : $preset['port'];
			$secure = 'custom' === $provider ? sanitize_key( isset( $data['secure'] ) ? $data['secure'] : '' ) : $preset['secure'];
			$username = sanitize_text_field( isset( $data['username'] ) ? $data['username'] : '' );
			$password = isset( $data['password'] ) ? (string) $data['password'] : '';

			if ( '' === $password ) {
				$existing = get_user_meta( $user_id, self::CONNECTION_META, true );
				$proposed = array(
					'provider' => $provider,
					'host'     => strtolower( $host ),
					'port'     => $port,
					'secure'   => $secure,
					'username' => $username,
				);
				if ( is_array( $existing ) && self::smtp_tuple( $existing ) === self::smtp_tuple( $proposed ) ) {
					$password = isset( $existing['password'] ) ? Oddpost_Crypto::decrypt( $existing['password'] ) : '';
				}
			}
			if ( is_wp_error( $password ) || '' === $password || '' === $username ) {
				return new WP_Error( 'oddpost_credentials_missing', __( 'Enter the account username and an app password.', 'oddpost' ), array( 'status' => 400 ) );
			}
			if ( ! self::is_safe_smtp_host( $host ) ) {
				return new WP_Error( 'oddpost_host_invalid', __( 'The SMTP host must be a public hostname.', 'oddpost' ), array( 'status' => 400 ) );
			}
			if ( $port < 1 || $port > 65535 || ! in_array( $secure, array( 'tls', 'ssl' ), true ) ) {
				return new WP_Error( 'oddpost_smtp_invalid', __( 'Enter a valid SMTP port and encryption method.', 'oddpost' ), array( 'status' => 400 ) );
			}

			$encrypted = Oddpost_Crypto::encrypt( $password );
			if ( is_wp_error( $encrypted ) ) {
				return $encrypted;
			}
			$connection['host']     = strtolower( $host );
			$connection['port']     = $port;
			$connection['secure']   = $secure;
			$connection['username'] = $username;
			$connection['password'] = $encrypted;
		}

		update_user_meta( $user_id, self::CONNECTION_META, $connection );
		return $this->get_connection_summary( $user_id );
	}

	/**
	 * Delete a saved connection.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public function delete_connection( $user_id ) {
		$deleted = delete_user_meta( $user_id, self::CONNECTION_META );
		$exists  = function_exists( 'metadata_exists' )
			? metadata_exists( 'user', $user_id, self::CONNECTION_META )
			: '' !== get_user_meta( $user_id, self::CONNECTION_META, true );
		if ( $exists ) {
			return new WP_Error( 'oddpost_disconnect_failed', __( 'ODD Post could not remove the saved connection. Try again before leaving this screen.', 'oddpost' ), array( 'status' => 500 ) );
		}
		return (bool) $deleted || ! $exists;
	}

	/**
	 * Provider presets shown in the client.
	 *
	 * @return array
	 */
	public static function provider_presets() {
		$providers = self::provider_definitions();
		if ( ! self::custom_smtp_enabled() ) {
			unset( $providers['custom'] );
		}
		return $providers;
	}

	/** @return bool */
	public static function custom_smtp_enabled() {
		return (bool) apply_filters( 'oddpost_custom_smtp_enabled', false );
	}

	/** @return array */
	private static function provider_definitions() {
		return array(
			'wordpress' => array(),
			'gmail'     => array( 'host' => 'smtp.gmail.com', 'port' => 587, 'secure' => 'tls' ),
			'icloud'    => array( 'host' => 'smtp.mail.me.com', 'port' => 587, 'secure' => 'tls' ),
			'fastmail'  => array( 'host' => 'smtp.fastmail.com', 'port' => 465, 'secure' => 'ssl' ),
			'zoho'      => array( 'host' => 'smtp.zoho.com', 'port' => 465, 'secure' => 'ssl' ),
			'custom'    => array(),
		);
	}

	/** @return array */
	private static function allowed_wordpress_from_addresses( $user_id ) {
		$user    = get_userdata( $user_id );
		$default = $user && ! empty( $user->user_email ) ? array( $user->user_email ) : array();
		$allowed = apply_filters( 'oddpost_allowed_wordpress_from_addresses', $default, (int) $user_id );
		$result  = array();
		foreach ( (array) $allowed as $address ) {
			$address = strtolower( sanitize_email( $address ) );
			if ( is_email( $address ) ) {
				$result[] = $address;
			}
		}
		return array_values( array_unique( $result ) );
	}

	/** @return string */
	private static function smtp_tuple( $connection ) {
		return wp_json_encode(
			array(
				'provider' => sanitize_key( isset( $connection['provider'] ) ? $connection['provider'] : '' ),
				'host'     => strtolower( rtrim( trim( isset( $connection['host'] ) ? $connection['host'] : '' ), '.' ) ),
				'port'     => absint( isset( $connection['port'] ) ? $connection['port'] : 0 ),
				'secure'   => sanitize_key( isset( $connection['secure'] ) ? $connection['secure'] : '' ),
				'username' => sanitize_text_field( isset( $connection['username'] ) ? $connection['username'] : '' ),
			)
		);
	}

	/**
	 * Validate a public DNS hostname to avoid using the SMTP tester as SSRF.
	 *
	 * @param string $host Hostname.
	 * @return bool
	 */
	public static function is_safe_smtp_host( $host ) {
		return false !== self::resolve_safe_smtp_host( $host );
	}

	/**
	 * Resolve once, reject the complete answer if any address is non-public,
	 * and return one address for a pinned transport connection.
	 *
	 * @return string|false
	 */
	public static function resolve_safe_smtp_host( $host ) {
		if ( ! is_string( $host ) || '' === $host || strlen( $host ) > 253 || filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return false;
		}
		if ( ! preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}$/i', $host ) ) {
			return false;
		}
		$resolver = apply_filters( 'oddpost_smtp_dns_resolver', null, $host );
		$records  = is_callable( $resolver ) ? call_user_func( $resolver, $host ) : dns_get_record( $host, DNS_A | DNS_AAAA );
		if ( ! is_array( $records ) || empty( $records ) ) {
			return false;
		}
		$addresses = array();
		foreach ( $records as $record ) {
			$ip = isset( $record['ip'] ) ? $record['ip'] : ( isset( $record['ipv6'] ) ? $record['ipv6'] : '' );
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return false;
			}
			$addresses[] = $ip;
		}
		return empty( $addresses ) ? false : $addresses[0];
	}

	/** @return array */
	private function serialize_summary( $post ) {
		$modified_gmt = $post->post_modified_gmt;
		if ( empty( $modified_gmt ) || '0000-00-00 00:00:00' === $modified_gmt ) {
			$local        = ! empty( $post->post_modified ) ? $post->post_modified : $post->post_date;
			$modified_gmt = get_gmt_from_date( $local );
		}
		return array(
			'id'         => (int) $post->ID,
			'subject'    => (string) get_post_meta( $post->ID, '_oddpost_subject', true ),
			'to'         => (array) get_post_meta( $post->ID, '_oddpost_to', true ),
			'stationery' => (string) get_post_meta( $post->ID, '_oddpost_stationery', true ),
			'status'     => (string) get_post_meta( $post->ID, '_oddpost_status', true ),
			'modified'   => self::gmt_mysql_to_rfc3339( $modified_gmt ),
		);
	}

	/** @return array */
	private function serialize_draft( $post ) {
		$content = json_decode( $post->post_content, true );
		return array_merge(
			$this->serialize_summary( $post ),
			array(
				'content'     => is_array( $content ) ? $content : array(),
				'cc'          => (array) get_post_meta( $post->ID, '_oddpost_cc', true ),
				'bcc'         => (array) get_post_meta( $post->ID, '_oddpost_bcc', true ),
				'preheader'   => (string) get_post_meta( $post->ID, '_oddpost_preheader', true ),
				'html'        => (string) get_post_meta( $post->ID, '_oddpost_html', true ),
				'text'        => (string) get_post_meta( $post->ID, '_oddpost_text', true ),
				'attachments' => (array) get_post_meta( $post->ID, '_oddpost_attachments', true ),
				'sentAt'      => self::gmt_mysql_to_rfc3339( (string) get_post_meta( $post->ID, '_oddpost_sent_at', true ) ),
			)
		);
	}

	/**
	 * Serialize a WordPress GMT datetime with an explicit UTC designator.
	 *
	 * @param string $value MySQL-formatted GMT datetime.
	 * @return string
	 */
	public static function gmt_mysql_to_rfc3339( $value ) {
		if ( ! is_string( $value ) || '' === $value || '0000-00-00 00:00:00' === $value ) {
			return '';
		}
		$date = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $value, new DateTimeZone( 'UTC' ) );
		return $date instanceof DateTimeImmutable ? $date->format( 'Y-m-d\TH:i:s\Z' ) : '';
	}

	/** @return array */
	public function sanitize_address_list( $value ) {
		$input = is_array( $value ) ? $value : preg_split( '/[,;\\n]+/', (string) $value );
		$valid = array();
		foreach ( $input as $address ) {
			$address = sanitize_email( trim( (string) $address ) );
			if ( is_email( $address ) ) {
				$valid[] = strtolower( $address );
			}
		}
		return array_values( array_unique( array_slice( $valid, 0, self::MAX_RECIPIENTS ) ) );
	}

	/** @return array */
	public function sanitize_attachment_ids( $value, $user_id ) {
		$valid = array();
		foreach ( array_slice( array_map( 'absint', (array) $value ), 0, self::MAX_ATTACHMENTS ) as $attachment_id ) {
			$post = get_post( $attachment_id );
			if ( $post && 'attachment' === $post->post_type && (int) $post->post_author === (int) $user_id ) {
				$valid[] = $attachment_id;
			}
		}
		return array_values( array_unique( $valid ) );
	}

	/** @return string */
	public function sanitize_email_html( $html ) {
		$html = (string) $html;
		if ( strlen( $html ) > self::MAX_HTML_BYTES ) {
			$html = substr( $html, 0, self::MAX_HTML_BYTES );
		}
		$allowed = wp_kses_allowed_html( 'post' );
		foreach ( array( 'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'center' ) as $tag ) {
			$allowed[ $tag ] = array(
				'align' => true, 'bgcolor' => true, 'border' => true, 'cellpadding' => true,
				'cellspacing' => true, 'class' => true, 'data-id' => true, 'height' => true, 'id' => true,
				'role' => true, 'style' => true, 'valign' => true, 'width' => true,
			);
		}
		if ( isset( $allowed['img'] ) ) {
			$allowed['img']['srcset'] = true;
			$allowed['img']['sizes']  = true;
		}
		return wp_kses( $html, $allowed, array( 'http', 'https', 'mailto', 'tel' ) );
	}
}
