<?php
/**
 * User-owned drafts and connection settings.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_Store {
	const CONNECTION_META = '_oddpost_connection';
	const MAX_RECIPIENTS   = 20;
	const MAX_HTML_BYTES   = 524288;

	/**
	 * Return a user's draft summaries, newest first.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	public function list_drafts( $user_id ) {
		$posts = get_posts(
			array(
				'post_type'      => 'oddpost_letter',
				'post_status'    => array( 'draft', 'private' ),
				'author'         => $user_id,
				'posts_per_page' => 50,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);

		return array_map( array( $this, 'serialize_summary' ), $posts );
	}

	/**
	 * Load one user-owned draft.
	 *
	 * @param int $post_id Draft ID.
	 * @param int $user_id User ID.
	 * @return array|WP_Error
	 */
	public function get_draft( $post_id, $user_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'oddpost_letter' !== $post->post_type || (int) $post->post_author !== (int) $user_id ) {
			return new WP_Error( 'oddpost_draft_not_found', __( 'That letter was not found.', 'oddpost' ), array( 'status' => 404 ) );
		}

		return $this->serialize_draft( $post );
	}

	/**
	 * Create or update a user-owned draft.
	 *
	 * @param array $data Draft data.
	 * @param int   $user_id User ID.
	 * @return array|WP_Error
	 */
	public function save_draft( $data, $user_id ) {
		$post_id = isset( $data['id'] ) ? absint( $data['id'] ) : 0;
		if ( $post_id ) {
			$existing = get_post( $post_id );
			if ( ! $existing || 'oddpost_letter' !== $existing->post_type || (int) $existing->post_author !== (int) $user_id ) {
				return new WP_Error( 'oddpost_draft_not_found', __( 'That letter was not found.', 'oddpost' ), array( 'status' => 404 ) );
			}
		}

		$subject = sanitize_text_field( isset( $data['subject'] ) ? $data['subject'] : '' );
		$content = isset( $data['content'] ) && is_array( $data['content'] ) ? wp_json_encode( $data['content'] ) : '{}';
		$postarr = array(
			'ID'           => $post_id,
			'post_type'    => 'oddpost_letter',
			'post_status'  => 'draft',
			'post_author'  => $user_id,
			'post_title'   => '' !== $subject ? $subject : __( 'Untitled letter', 'oddpost' ),
			'post_content' => $content,
		);
		$saved   = wp_insert_post( wp_slash( $postarr ), true );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}

		$meta = array(
			'_oddpost_to'         => $this->sanitize_address_list( isset( $data['to'] ) ? $data['to'] : array() ),
			'_oddpost_cc'         => $this->sanitize_address_list( isset( $data['cc'] ) ? $data['cc'] : array() ),
			'_oddpost_bcc'        => $this->sanitize_address_list( isset( $data['bcc'] ) ? $data['bcc'] : array() ),
			'_oddpost_subject'    => $subject,
			'_oddpost_preheader'  => sanitize_text_field( isset( $data['preheader'] ) ? $data['preheader'] : '' ),
			'_oddpost_html'       => $this->sanitize_email_html( isset( $data['html'] ) ? $data['html'] : '' ),
			'_oddpost_text'       => sanitize_textarea_field( isset( $data['text'] ) ? $data['text'] : '' ),
			'_oddpost_stationery' => sanitize_key( isset( $data['stationery'] ) ? $data['stationery'] : 'nice-note' ),
			'_oddpost_attachments'=> $this->sanitize_attachment_ids( isset( $data['attachments'] ) ? $data['attachments'] : array(), $user_id ),
			'_oddpost_status'     => 'draft',
		);
		foreach ( $meta as $key => $value ) {
			update_post_meta( $saved, $key, $value );
		}

		return $this->get_draft( $saved, $user_id );
	}

	/**
	 * Delete a user-owned draft.
	 *
	 * @param int $post_id Draft ID.
	 * @param int $user_id User ID.
	 * @return true|WP_Error
	 */
	public function delete_draft( $post_id, $user_id ) {
		$draft = $this->get_draft( $post_id, $user_id );
		if ( is_wp_error( $draft ) ) {
			return $draft;
		}
		return (bool) wp_delete_post( $post_id, true );
	}

	/**
	 * Get a safe connection summary, with no password.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	public function get_connection_summary( $user_id ) {
		$connection = get_user_meta( $user_id, self::CONNECTION_META, true );
		if ( ! is_array( $connection ) || empty( $connection['provider'] ) ) {
			return array(
				'connected' => false,
				'provider'  => '',
			);
		}
		unset( $connection['password'] );
		$connection['connected']   = true;
		$connection['hasPassword'] = 'wordpress' !== $connection['provider'];
		return $connection;
	}

	/**
	 * Return the full connection to trusted server code.
	 *
	 * @param int $user_id User ID.
	 * @return array|WP_Error
	 */
	public function get_connection( $user_id ) {
		$connection = get_user_meta( $user_id, self::CONNECTION_META, true );
		if ( ! is_array( $connection ) || empty( $connection['provider'] ) ) {
			return new WP_Error( 'oddpost_not_connected', __( 'Connect a sending account before sending.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( 'wordpress' !== $connection['provider'] ) {
			if ( empty( $connection['host'] ) || ! self::is_safe_smtp_host( $connection['host'] ) ) {
				return new WP_Error( 'oddpost_host_invalid', __( 'The saved SMTP host is no longer resolving to a public address. Reconnect the account.', 'oddpost' ), array( 'status' => 400 ) );
			}
			$password = Oddpost_Crypto::decrypt( isset( $connection['password'] ) ? $connection['password'] : '' );
			if ( is_wp_error( $password ) ) {
				return $password;
			}
			$connection['password'] = $password;
		}
		return $connection;
	}

	/**
	 * Save a validated connection.
	 *
	 * @param array $data Connection input.
	 * @param int   $user_id User ID.
	 * @return array|WP_Error
	 */
	public function save_connection( $data, $user_id ) {
		$provider   = sanitize_key( isset( $data['provider'] ) ? $data['provider'] : '' );
		$presets    = self::provider_presets();
		$connection = array(
			'provider'  => $provider,
			'fromName'  => sanitize_text_field( isset( $data['fromName'] ) ? $data['fromName'] : '' ),
			'fromEmail' => sanitize_email( isset( $data['fromEmail'] ) ? $data['fromEmail'] : '' ),
			'replyTo'   => sanitize_email( isset( $data['replyTo'] ) ? $data['replyTo'] : '' ),
		);

		if ( ! isset( $presets[ $provider ] ) ) {
			return new WP_Error( 'oddpost_provider_invalid', __( 'Choose a supported sending method.', 'oddpost' ), array( 'status' => 400 ) );
		}
		if ( ! is_email( $connection['fromEmail'] ) ) {
			return new WP_Error( 'oddpost_from_invalid', __( 'Enter a valid From email address.', 'oddpost' ), array( 'status' => 400 ) );
		}

		if ( 'wordpress' !== $provider ) {
			$preset = $presets[ $provider ];
			$host   = 'custom' === $provider ? sanitize_text_field( isset( $data['host'] ) ? $data['host'] : '' ) : $preset['host'];
			$port   = 'custom' === $provider ? absint( isset( $data['port'] ) ? $data['port'] : 0 ) : $preset['port'];
			$secure = 'custom' === $provider ? sanitize_key( isset( $data['secure'] ) ? $data['secure'] : '' ) : $preset['secure'];
			$username = sanitize_text_field( isset( $data['username'] ) ? $data['username'] : '' );
			$password = isset( $data['password'] ) ? (string) $data['password'] : '';

			if ( '' === $password ) {
				$existing = get_user_meta( $user_id, self::CONNECTION_META, true );
				if ( is_array( $existing ) && $provider === ( isset( $existing['provider'] ) ? $existing['provider'] : '' ) ) {
					$password = isset( $existing['password'] ) ? Oddpost_Crypto::decrypt( $existing['password'] ) : '';
				}
			}
			if ( is_wp_error( $password ) || '' === $password || '' === $username ) {
				return new WP_Error( 'oddpost_credentials_missing', __( 'Enter the account username and an app password.', 'oddpost' ), array( 'status' => 400 ) );
			}
			if ( ! self::is_safe_smtp_host( $host ) ) {
				return new WP_Error( 'oddpost_host_invalid', __( 'The SMTP host must be a public hostname.', 'oddpost' ), array( 'status' => 400 ) );
			}
			if ( $port < 1 || $port > 65535 || ! in_array( $secure, array( 'tls', 'ssl' ), true ) ) {
				return new WP_Error( 'oddpost_smtp_invalid', __( 'Enter a valid SMTP port and encryption method.', 'oddpost' ), array( 'status' => 400 ) );
			}

			$encrypted = Oddpost_Crypto::encrypt( $password );
			if ( is_wp_error( $encrypted ) ) {
				return $encrypted;
			}
			$connection['host']     = strtolower( $host );
			$connection['port']     = $port;
			$connection['secure']   = $secure;
			$connection['username'] = $username;
			$connection['password'] = $encrypted;
		}

		update_user_meta( $user_id, self::CONNECTION_META, $connection );
		return $this->get_connection_summary( $user_id );
	}

	/**
	 * Delete a saved connection.
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	public function delete_connection( $user_id ) {
		return delete_user_meta( $user_id, self::CONNECTION_META );
	}

	/**
	 * Provider presets shown in the client.
	 *
	 * @return array
	 */
	public static function provider_presets() {
		return array(
			'wordpress' => array(),
			'gmail'     => array( 'host' => 'smtp.gmail.com', 'port' => 587, 'secure' => 'tls' ),
			'icloud'    => array( 'host' => 'smtp.mail.me.com', 'port' => 587, 'secure' => 'tls' ),
			'fastmail'  => array( 'host' => 'smtp.fastmail.com', 'port' => 465, 'secure' => 'ssl' ),
			'zoho'      => array( 'host' => 'smtp.zoho.com', 'port' => 465, 'secure' => 'ssl' ),
			'custom'    => array(),
		);
	}

	/**
	 * Validate a public DNS hostname to avoid using the SMTP tester as SSRF.
	 *
	 * @param string $host Hostname.
	 * @return bool
	 */
	public static function is_safe_smtp_host( $host ) {
		if ( ! is_string( $host ) || '' === $host || strlen( $host ) > 253 || filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return false;
		}
		if ( ! preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}$/i', $host ) ) {
			return false;
		}
		$records = dns_get_record( $host, DNS_A | DNS_AAAA );
		if ( ! is_array( $records ) || empty( $records ) ) {
			return false;
		}
		foreach ( $records as $record ) {
			$ip = isset( $record['ip'] ) ? $record['ip'] : ( isset( $record['ipv6'] ) ? $record['ipv6'] : '' );
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return false;
			}
		}
		return true;
	}

	/** @return array */
	private function serialize_summary( $post ) {
		return array(
			'id'         => (int) $post->ID,
			'subject'    => (string) get_post_meta( $post->ID, '_oddpost_subject', true ),
			'to'         => (array) get_post_meta( $post->ID, '_oddpost_to', true ),
			'stationery' => (string) get_post_meta( $post->ID, '_oddpost_stationery', true ),
			'status'     => (string) get_post_meta( $post->ID, '_oddpost_status', true ),
			'modified'   => mysql_to_rfc3339( $post->post_modified_gmt ),
		);
	}

	/** @return array */
	private function serialize_draft( $post ) {
		$content = json_decode( $post->post_content, true );
		return array_merge(
			$this->serialize_summary( $post ),
			array(
				'content'     => is_array( $content ) ? $content : array(),
				'cc'          => (array) get_post_meta( $post->ID, '_oddpost_cc', true ),
				'bcc'         => (array) get_post_meta( $post->ID, '_oddpost_bcc', true ),
				'preheader'   => (string) get_post_meta( $post->ID, '_oddpost_preheader', true ),
				'html'        => (string) get_post_meta( $post->ID, '_oddpost_html', true ),
				'text'        => (string) get_post_meta( $post->ID, '_oddpost_text', true ),
				'attachments' => (array) get_post_meta( $post->ID, '_oddpost_attachments', true ),
				'sentAt'      => (string) get_post_meta( $post->ID, '_oddpost_sent_at', true ),
			)
		);
	}

	/** @return array */
	public function sanitize_address_list( $value ) {
		$input = is_array( $value ) ? $value : preg_split( '/[,;\\n]+/', (string) $value );
		$valid = array();
		foreach ( $input as $address ) {
			$address = sanitize_email( trim( (string) $address ) );
			if ( is_email( $address ) ) {
				$valid[] = strtolower( $address );
			}
		}
		return array_values( array_unique( array_slice( $valid, 0, self::MAX_RECIPIENTS ) ) );
	}

	/** @return array */
	public function sanitize_attachment_ids( $value, $user_id ) {
		$valid = array();
		foreach ( array_slice( array_map( 'absint', (array) $value ), 0, 10 ) as $attachment_id ) {
			$post = get_post( $attachment_id );
			if ( $post && 'attachment' === $post->post_type && ( (int) $post->post_author === (int) $user_id || current_user_can( 'edit_post', $attachment_id ) ) ) {
				$valid[] = $attachment_id;
			}
		}
		return array_values( array_unique( $valid ) );
	}

	/** @return string */
	public function sanitize_email_html( $html ) {
		$html = (string) $html;
		if ( strlen( $html ) > self::MAX_HTML_BYTES ) {
			$html = substr( $html, 0, self::MAX_HTML_BYTES );
		}
		$allowed = wp_kses_allowed_html( 'post' );
		foreach ( array( 'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'center' ) as $tag ) {
			$allowed[ $tag ] = array(
				'align' => true, 'bgcolor' => true, 'border' => true, 'cellpadding' => true,
				'cellspacing' => true, 'class' => true, 'height' => true, 'id' => true,
				'role' => true, 'style' => true, 'valign' => true, 'width' => true,
			);
		}
		if ( isset( $allowed['img'] ) ) {
			$allowed['img']['srcset'] = true;
			$allowed['img']['sizes']  = true;
		}
		$allowed['style'] = array( 'type' => true );
		return wp_kses( $html, $allowed, array( 'http', 'https', 'mailto', 'tel' ) );
	}
}
