<?php
/**
 * Durable idempotency transactions and atomic delivery rate buckets.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_Send_Store {
	const STALE_SENDING_SECONDS = 300;

	/** @var wpdb */
	private $database;
	/** @var callable|null */
	private $clock;

	public function __construct( $database = null, $clock = null ) {
		global $wpdb;
		$this->database = $database ? $database : $wpdb;
		$this->clock    = is_callable( $clock ) ? $clock : null;
	}

	/** @return string */
	public static function sends_table_name( $database = null ) {
		global $wpdb;
		$database = $database ? $database : $wpdb;
		return $database->prefix . 'oddpost_sends';
	}

	/** @return string */
	public static function rates_table_name( $database = null ) {
		global $wpdb;
		$database = $database ? $database : $wpdb;
		return $database->prefix . 'oddpost_rate_limits';
	}

	/** Remove only one deleted user's delivery ledger and user-scoped rate buckets. */
	public static function delete_user_data( $user_id, $database = null ) {
		global $wpdb;
		$database = $database ? $database : $wpdb;
		$user_id = absint( $user_id );
		if ( ! $user_id ) return;
		$database->delete( self::sends_table_name( $database ), array( 'user_id' => $user_id ), array( '%d' ) );
		foreach ( array( 'send:user:' . $user_id, 'test:user:' . $user_id ) as $key ) {
			$database->delete( self::rates_table_name( $database ), array( 'bucket_key' => $key ), array( '%s' ) );
		}
	}

	/**
	 * Create or update the per-site transaction tables.
	 *
	 * @return true|WP_Error
	 */
	public static function install_schema() {
		global $wpdb;
		if ( ! function_exists( 'dbDelta' ) ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		}
		$collate = $wpdb->get_charset_collate();
		$sends   = self::sends_table_name( $wpdb );
		$rates   = self::rates_table_name( $wpdb );
		$sql     = "CREATE TABLE {$sends} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			token_hash char(64) NOT NULL,
			request_hash char(64) NOT NULL,
			artifact_hash char(64) NOT NULL,
			duplicate_generation int(10) unsigned NOT NULL DEFAULT 0,
			status varchar(32) NOT NULL,
			draft_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			accepted_at datetime NULL,
			safe_error_code varchar(64) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY user_token (user_id,token_hash),
			UNIQUE KEY user_artifact_copy (user_id,artifact_hash,duplicate_generation),
			KEY status_updated (status,updated_at)
		) {$collate};
		CREATE TABLE {$rates} (
			bucket_key varchar(191) NOT NULL,
			request_count int(10) unsigned NOT NULL DEFAULT 0,
			reset_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (bucket_key),
			KEY reset_at (reset_at)
		) {$collate};";
		dbDelta( $sql );

		foreach ( array( $sends, $rates ) as $table ) {
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
			if ( $table !== $found ) {
				return new WP_Error( 'oddpost_schema_failed', __( 'ODD Post could not prepare its delivery safety records.', 'oddpost' ) );
			}
		}
		return true;
	}

	/**
	 * Atomically acquire a user/token transaction.
	 *
	 * @return array|WP_Error
	 */
	public function acquire( $user_id, $token, $request_hash, $artifact_hash, $allow_duplicate = false, $duplicate_of = 0 ) {
		if ( ! is_string( $token ) || ! preg_match( '/^[A-Za-z0-9._:-]{16,128}$/', $token ) || ! is_string( $request_hash ) || ! preg_match( '/^[a-f0-9]{64}$/', $request_hash ) || ! is_string( $artifact_hash ) || ! preg_match( '/^[a-f0-9]{64}$/', $artifact_hash ) ) {
			return new WP_Error( 'oddpost_send_token_invalid', __( 'The send request is missing its safety token.', 'oddpost' ), array( 'status' => 400 ) );
		}
		$table      = self::sends_table_name( $this->database );
		$token_hash = hash( 'sha256', $token );
		$now        = $this->mysql_now();
		$token_row  = $this->find_by_token( $user_id, $token_hash );
		if ( is_array( $token_row ) ) {
			if ( ! hash_equals( $token_row['request_hash'], $request_hash ) || ! hash_equals( $token_row['artifact_hash'], $artifact_hash ) ) {
				return new WP_Error( 'oddpost_send_token_conflict', __( 'This send token belongs to a different final letter.', 'oddpost' ), array( 'status' => 409 ) );
			}
			if ( 'failed-before-handoff' === $token_row['status'] ) {
				$latest = $this->find_latest_artifact( $user_id, $artifact_hash );
				if ( is_array( $latest ) && (int) $latest['id'] !== (int) $token_row['id'] ) {
					$latest_state = $this->row_state( $latest );
					if ( is_wp_error( $latest_state ) || 'in_progress' === $latest_state['action'] ) {
						return $latest_state;
					}
					if ( in_array( $latest_state['action'], array( 'accepted', 'uncertain' ), true ) ) {
						return array( 'action' => 'confirmation_required', 'row' => $latest_state['row'] );
					}
				}
			}
			return $this->resume_token_row( $token_row, $request_hash );
		}

		$history    = $this->find_latest_artifact( $user_id, $artifact_hash );
		$generation = 0;
		if ( is_array( $history ) ) {
			$history_state = $this->row_state( $history );
			if ( is_wp_error( $history_state ) ) {
				return $history_state;
			}
			$history = isset( $history_state['row'] ) ? $history_state['row'] : $history;
			if ( 'in_progress' === $history_state['action'] ) {
				return $history_state;
			}
			if ( in_array( $history_state['action'], array( 'accepted', 'uncertain' ), true ) ) {
				if ( true !== $allow_duplicate || (int) $duplicate_of !== (int) $history['id'] ) {
					return array( 'action' => 'confirmation_required', 'row' => $history );
				}
			}
			$generation = (int) $history['duplicate_generation'] + 1;
		}
		$sql        = $this->database->prepare(
			"INSERT IGNORE INTO {$table} (user_id, token_hash, request_hash, artifact_hash, duplicate_generation, status, draft_id, created_at, updated_at, safe_error_code) VALUES (%d, %s, %s, %s, %d, 'sending', 0, %s, %s, '')",
			(int) $user_id,
			$token_hash,
			$request_hash,
			$artifact_hash,
			$generation,
			$now,
			$now
		);
		$inserted   = $this->database->query( $sql );
		if ( false === $inserted ) {
			return $this->database_error();
		}
		if ( 1 === (int) $inserted ) {
			return array( 'action' => 'acquired', 'id' => (int) $this->database->insert_id );
		}

		$row = $this->find_by_token( $user_id, $token_hash );
		if ( is_array( $row ) ) {
			if ( ! hash_equals( $row['request_hash'], $request_hash ) || ! hash_equals( $row['artifact_hash'], $artifact_hash ) ) {
				return new WP_Error( 'oddpost_send_token_conflict', __( 'This send token belongs to a different final letter.', 'oddpost' ), array( 'status' => 409 ) );
			}
			return $this->resume_token_row( $row, $request_hash );
		}
		$row = $this->find_artifact_generation( $user_id, $artifact_hash, $generation );
		return is_array( $row ) ? $this->row_state( $row ) : $this->database_error();
	}

	/** @return array|WP_Error */
	private function resume_token_row( $row, $request_hash ) {
		$table = self::sends_table_name( $this->database );
		$now   = $this->mysql_now();
		if ( 'failed-before-handoff' === $row['status'] ) {
			$reacquired = $this->database->query(
				$this->database->prepare(
					"UPDATE {$table} SET status = 'sending', updated_at = %s, safe_error_code = '' WHERE id = %d AND status = 'failed-before-handoff' AND request_hash = %s",
					$now,
					(int) $row['id'],
					$request_hash
				)
			);
			if ( false === $reacquired ) {
				return $this->database_error();
			}
			if ( 1 === (int) $reacquired ) {
				return array( 'action' => 'acquired', 'id' => (int) $row['id'] );
			}
			$row = $this->find_by_id( (int) $row['id'] );
			return is_array( $row ) ? $this->row_state( $row ) : $this->database_error();
		}
		return $this->row_state( $row );
	}

	/** @return array|WP_Error */
	private function row_state( $row ) {
		$table      = self::sends_table_name( $this->database );
		$now        = $this->mysql_now();
		$updated_at = strtotime( $row['updated_at'] . ' UTC' );
		if ( 'sending' === $row['status'] && false !== $updated_at && $updated_at <= $this->now() - self::STALE_SENDING_SECONDS ) {
			$changed = $this->database->query(
				$this->database->prepare(
					"UPDATE {$table} SET status = 'uncertain', updated_at = %s, safe_error_code = 'stale_sending' WHERE id = %d AND status = 'sending' AND updated_at = %s",
					$now,
					(int) $row['id'],
					$row['updated_at']
				)
			);
			if ( false === $changed ) {
				return $this->database_error();
			}
			if ( 1 === (int) $changed ) {
				$row['status']          = 'uncertain';
				$row['safe_error_code'] = 'stale_sending';
				return array( 'action' => 'uncertain', 'row' => $row );
			}
			$row = $this->find_by_id( (int) $row['id'] );
			return is_array( $row ) ? $this->existing_state( $row ) : $this->database_error();
		}
		return $this->existing_state( $row );
	}

	/** @return true|WP_Error */
	public function mark_failed_before_handoff( $id, $code ) {
		return $this->transition( $id, 'sending', 'failed-before-handoff', $code );
	}

	/** @return true|WP_Error */
	public function mark_uncertain( $id, $code ) {
		return $this->transition( $id, 'sending', 'uncertain', $code );
	}

	/** @return array|WP_Error */
	public function mark_accepted( $id ) {
		$table  = self::sends_table_name( $this->database );
		$now    = $this->mysql_now();
		$result = $this->database->query(
			$this->database->prepare(
				"UPDATE {$table} SET status = 'accepted', accepted_at = %s, updated_at = %s, safe_error_code = '' WHERE id = %d AND status = 'sending'",
				$now,
				$now,
				(int) $id
			)
		);
		if ( 1 !== (int) $result ) {
			return false === $result ? $this->database_error() : new WP_Error( 'oddpost_send_state_failed', __( 'ODD Post could not safely record provider acceptance.', 'oddpost' ), array( 'status' => 503 ) );
		}
		return array( 'accepted_at' => $now );
	}

	/** @return true|WP_Error */
	public function set_draft_id( $id, $draft_id ) {
		$table  = self::sends_table_name( $this->database );
		$result = $this->database->query(
			$this->database->prepare(
				"UPDATE {$table} SET draft_id = %d, updated_at = %s WHERE id = %d AND status = 'accepted'",
				(int) $draft_id,
				$this->mysql_now(),
				(int) $id
			)
		);
		return 1 === (int) $result ? true : ( false === $result ? $this->database_error() : new WP_Error( 'oddpost_send_state_failed', __( 'ODD Post could not link the accepted message to its saved copy.', 'oddpost' ), array( 'status' => 503 ) ) );
	}

	/** @return true|WP_Error */
	public function consume_send_rate( $user_id ) {
		$user_limit = $this->limit( 'oddpost_send_user_hour_limit', 10, $user_id );
		$site_limit = $this->limit( 'oddpost_send_site_day_limit', 50, 0 );
		return $this->consume_rates(
			array(
				array( 'key' => 'send:user:' . (int) $user_id, 'limit' => $user_limit, 'window' => HOUR_IN_SECONDS ),
				array( 'key' => 'send:site', 'limit' => $site_limit, 'window' => DAY_IN_SECONDS ),
			),
			'oddpost_send_rate_limited',
			__( 'ODD Post has reached its sending limit. Try again after the safety window resets.', 'oddpost' )
		);
	}

	/** @return true|WP_Error */
	public function consume_connection_test_rate( $user_id ) {
		$limit = $this->limit( 'oddpost_connection_test_user_limit', 5, $user_id );
		return $this->consume_rates(
			array( array( 'key' => 'test:user:' . (int) $user_id, 'limit' => $limit, 'window' => 15 * MINUTE_IN_SECONDS ) ),
			'oddpost_connection_test_rate_limited',
			__( 'Too many connection tests were requested. Try again after the safety window resets.', 'oddpost' )
		);
	}

	/** @return array|WP_Error */
	private function find_by_token( $user_id, $token_hash ) {
		$table = self::sends_table_name( $this->database );
		return $this->database->get_row(
			$this->database->prepare( "SELECT * FROM {$table} WHERE user_id = %d AND token_hash = %s LIMIT 1", (int) $user_id, $token_hash ),
			ARRAY_A
		);
	}

	/** @return array|null */
	private function find_by_id( $id ) {
		$table = self::sends_table_name( $this->database );
		return $this->database->get_row( $this->database->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", (int) $id ), ARRAY_A );
	}

	/** @return array|null */
	private function find_latest_artifact( $user_id, $artifact_hash ) {
		$table = self::sends_table_name( $this->database );
		return $this->database->get_row( $this->database->prepare( "SELECT * FROM {$table} WHERE user_id = %d AND artifact_hash = %s ORDER BY duplicate_generation DESC, id DESC LIMIT 1", (int) $user_id, $artifact_hash ), ARRAY_A );
	}

	/** @return array|null */
	private function find_artifact_generation( $user_id, $artifact_hash, $generation ) {
		$table = self::sends_table_name( $this->database );
		return $this->database->get_row( $this->database->prepare( "SELECT * FROM {$table} WHERE user_id = %d AND artifact_hash = %s AND duplicate_generation = %d LIMIT 1", (int) $user_id, $artifact_hash, (int) $generation ), ARRAY_A );
	}

	/** @return array */
	private function existing_state( $row ) {
		return 'accepted' === $row['status']
			? array( 'action' => 'accepted', 'row' => $row )
			: ( 'uncertain' === $row['status']
				? array( 'action' => 'uncertain', 'row' => $row )
				: ( 'failed-before-handoff' === $row['status']
					? array( 'action' => 'failed_before_handoff', 'row' => $row )
					: array( 'action' => 'in_progress', 'row' => $row ) ) );
	}

	/** @return true|WP_Error */
	private function transition( $id, $from, $to, $code ) {
		$table  = self::sends_table_name( $this->database );
		$code   = substr( sanitize_key( (string) $code ), 0, 64 );
		$result = $this->database->query(
			$this->database->prepare(
				"UPDATE {$table} SET status = %s, updated_at = %s, safe_error_code = %s WHERE id = %d AND status = %s",
				$to,
				$this->mysql_now(),
				$code,
				(int) $id,
				$from
			)
		);
		return 1 === (int) $result ? true : ( false === $result ? $this->database_error() : new WP_Error( 'oddpost_send_state_failed', __( 'ODD Post could not update its delivery safety record.', 'oddpost' ), array( 'status' => 503 ) ) );
	}

	/** @return true|WP_Error */
	private function consume_rates( $specifications, $error_code, $message ) {
		if ( false === $this->database->query( 'START TRANSACTION' ) ) {
			return $this->database_error();
		}
		foreach ( $specifications as $specification ) {
			$consumed = $this->consume_rate( $specification['key'], $specification['limit'], $specification['window'], $error_code, $message );
			if ( is_wp_error( $consumed ) ) {
				$this->database->query( 'ROLLBACK' );
				return $consumed;
			}
		}
		if ( false === $this->database->query( 'COMMIT' ) ) {
			$this->database->query( 'ROLLBACK' );
			return $this->database_error();
		}
		return true;
	}

	/** @return true|WP_Error */
	private function consume_rate( $key, $limit, $window, $error_code, $message ) {
		$table    = self::rates_table_name( $this->database );
		$now      = $this->now();
		$now_sql  = gmdate( 'Y-m-d H:i:s', $now );
		$reset_at = gmdate( 'Y-m-d H:i:s', $now + (int) $window );
		$sql      = $this->database->prepare(
			"INSERT INTO {$table} (bucket_key, request_count, reset_at, updated_at) VALUES (%s, 1, %s, %s)
			ON DUPLICATE KEY UPDATE request_count = IF(reset_at <= VALUES(updated_at), 1, request_count + 1), reset_at = IF(reset_at <= VALUES(updated_at), VALUES(reset_at), reset_at), updated_at = VALUES(updated_at)",
			$key,
			$reset_at,
			$now_sql
		);
		if ( false === $this->database->query( $sql ) ) {
			return $this->database_error();
		}
		$row = $this->database->get_row( $this->database->prepare( "SELECT request_count, reset_at FROM {$table} WHERE bucket_key = %s LIMIT 1 FOR UPDATE", $key ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return $this->database_error();
		}
		if ( (int) $row['request_count'] > (int) $limit ) {
			$reset = strtotime( $row['reset_at'] . ' UTC' );
			return new WP_Error( $error_code, $message, array( 'status' => 429, 'retryAfter' => false === $reset ? (int) $window : max( 1, $reset - $now ) ) );
		}
		return true;
	}

	/** @return int */
	private function limit( $filter, $default, $user_id ) {
		return max( 1, (int) apply_filters( $filter, $default, (int) $user_id ) );
	}

	/** @return int */
	private function now() {
		return $this->clock ? (int) call_user_func( $this->clock ) : time();
	}

	/** @return string */
	private function mysql_now() {
		return gmdate( 'Y-m-d H:i:s', $this->now() );
	}

	/** @return WP_Error */
	private function database_error() {
		return new WP_Error( 'oddpost_send_state_failed', __( 'ODD Post could not safely record this delivery request.', 'oddpost' ), array( 'status' => 503 ) );
	}
}
