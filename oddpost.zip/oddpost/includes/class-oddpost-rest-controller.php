<?php
/**
 * REST controller for the ODD Post native window.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_REST_Controller {
	/** @var Oddpost_Store */
	private $store;
	/** @var Oddpost_Mailer */
	private $mailer;
	/** @var Oddpost_Message_Preparer */
	private $preparer;
	/** @var Oddpost_Send_Store */
	private $send_store;

	public function __construct( $store, $mailer, $preparer = null, $send_store = null ) {
		$this->store      = $store;
		$this->mailer     = $mailer;
		$this->preparer   = $preparer ? $preparer : new Oddpost_Message_Preparer( $store );
		$this->send_store = $send_store ? $send_store : new Oddpost_Send_Store();
	}

	public function register_routes() {
		$permission = array( $this, 'permissions_check' );
		$send_permission = array( $this, 'send_permissions_check' );
		register_rest_route( 'oddpost/v1', '/bootstrap', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'bootstrap' ), 'permission_callback' => $permission ) );
		register_rest_route( 'oddpost/v1', '/drafts', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'list_drafts' ), 'permission_callback' => $permission ),
			array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'save_draft' ), 'permission_callback' => $permission ),
		) );
		register_rest_route( 'oddpost/v1', '/drafts/(?P<id>\\d+)', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'get_draft' ), 'permission_callback' => $permission ),
			array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( $this, 'delete_draft' ), 'permission_callback' => $permission ),
		) );
		register_rest_route( 'oddpost/v1', '/connection', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'get_connection' ), 'permission_callback' => $send_permission ),
			array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'save_connection' ), 'permission_callback' => $send_permission ),
			array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( $this, 'delete_connection' ), 'permission_callback' => $send_permission ),
		) );
		register_rest_route( 'oddpost/v1', '/connection/test', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'test_connection' ), 'permission_callback' => $send_permission ) );
		register_rest_route( 'oddpost/v1', '/prepare', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'prepare' ), 'permission_callback' => $permission ) );
		register_rest_route( 'oddpost/v1', '/send', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'send' ), 'permission_callback' => $send_permission ) );
	}

	public function permissions_check() {
		return current_user_can( 'edit_posts' );
	}

	public function send_permissions_check() {
		return current_user_can( 'oddpost_send_mail' );
	}

	public function bootstrap() {
		$can_send = current_user_can( 'oddpost_send_mail' );
		return rest_ensure_response( array(
			'drafts'     => $this->store->list_drafts( get_current_user_id() ),
			'connection' => $can_send ? $this->store->get_connection_summary( get_current_user_id() ) : array( 'connected' => false, 'provider' => '' ),
			'providers'  => array_keys( Oddpost_Store::provider_presets() ),
			'capabilities' => array( 'canSend' => $can_send ),
		) );
	}

	public function list_drafts() {
		return rest_ensure_response( $this->store->list_drafts( get_current_user_id() ) );
	}

	public function get_draft( $request ) {
		$draft = $this->store->get_draft( absint( $request['id'] ), get_current_user_id() );
		return is_wp_error( $draft ) ? $draft : rest_ensure_response( $draft );
	}

	public function save_draft( $request ) {
		$draft = $this->store->save_draft( (array) $request->get_json_params(), get_current_user_id() );
		return is_wp_error( $draft ) ? $draft : rest_ensure_response( $draft );
	}

	public function delete_draft( $request ) {
		$deleted = $this->store->delete_draft( absint( $request['id'] ), get_current_user_id() );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}
		return rest_ensure_response( array( 'deleted' => (bool) $deleted ) );
	}

	public function get_connection() {
		return rest_ensure_response( $this->store->get_connection_summary( get_current_user_id() ) );
	}

	public function save_connection( $request ) {
		$connection = $this->store->save_connection( (array) $request->get_json_params(), get_current_user_id() );
		return is_wp_error( $connection ) ? $connection : rest_ensure_response( $connection );
	}

	public function delete_connection() {
		$deleted = $this->store->delete_connection( get_current_user_id() );
		return is_wp_error( $deleted ) ? $deleted : rest_ensure_response( array( 'deleted' => true ) );
	}

	public function test_connection() {
		$rate = $this->send_store->consume_connection_test_rate( get_current_user_id() );
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}
		$connection = $this->store->get_connection( get_current_user_id() );
		if ( is_wp_error( $connection ) ) {
			return $connection;
		}
		$tested = $this->mailer->test_connection( $connection );
		if ( is_wp_error( $tested ) ) {
			return $tested;
		}
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public function prepare( $request ) {
		$prepared = $this->preparer->prepare( (array) $request->get_json_params(), get_current_user_id() );
		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}
		unset( $prepared['attachmentPaths'] );
		return rest_ensure_response( $prepared );
	}

	public function send( $request ) {
		$user_id = get_current_user_id();
		$input   = (array) $request->get_json_params();
		$token   = isset( $input['idempotencyKey'] ) && is_string( $input['idempotencyKey'] ) ? $input['idempotencyKey'] : '';
		if ( ! preg_match( '/^[A-Za-z0-9._:-]{16,128}$/', $token ) ) {
			return new WP_Error( 'oddpost_send_token_invalid', __( 'The send request is missing its safety token.', 'oddpost' ), array( 'status' => 400 ) );
		}

		$prepared = $this->preparer->prepare( $input, $user_id );
		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}
		$expected_hash = isset( $input['artifactHash'] ) ? (string) $input['artifactHash'] : '';
		if ( 64 !== strlen( $expected_hash ) || ! hash_equals( $prepared['artifactHash'], $expected_hash ) ) {
			return new WP_Error( 'oddpost_artifact_changed', __( 'The final letter changed after preview. Review it once more before sending.', 'oddpost' ), array( 'status' => 409 ) );
		}
		$connection = $this->store->get_connection( $user_id );
		if ( is_wp_error( $connection ) ) {
			return $connection;
		}
		$request_hash = $this->request_hash( $prepared, $connection );
		$allow_duplicate = isset( $input['allowDuplicate'] ) && true === $input['allowDuplicate'];
		$duplicate_of    = isset( $input['duplicateOf'] ) ? absint( $input['duplicateOf'] ) : 0;
		$state           = $this->send_store->acquire( $user_id, $token, $request_hash, $prepared['artifactHash'], $allow_duplicate, $duplicate_of );
		if ( is_wp_error( $state ) ) {
			return $state;
		}
		if ( 'accepted' === $state['action'] ) {
			return rest_ensure_response( $this->accepted_response( $state['row'], true ) );
		}
		if ( 'uncertain' === $state['action'] ) {
			return $this->uncertain_error( isset( $state['row']['id'] ) ? (int) $state['row']['id'] : 0 );
		}
		if ( 'confirmation_required' === $state['action'] ) {
			return new WP_Error(
				'oddpost_send_duplicate_confirmation_required',
				__( 'This exact letter already has delivery history. Check the sending account, then click Send again to explicitly confirm a new copy.', 'oddpost' ),
				array(
					'status'         => 409,
					'duplicateOf'    => isset( $state['row']['id'] ) ? (int) $state['row']['id'] : 0,
					'previousStatus' => isset( $state['row']['status'] ) ? (string) $state['row']['status'] : 'uncertain',
				)
			);
		}
		if ( 'in_progress' === $state['action'] ) {
			return new WP_Error( 'oddpost_send_in_progress', __( 'This delivery request is already being processed. Wait before checking again.', 'oddpost' ), array( 'status' => 409 ) );
		}
		if ( 'failed_before_handoff' === $state['action'] ) {
			return new WP_Error( 'oddpost_send_retry_required', __( 'This delivery request stopped before handoff. Review the final letter and try again.', 'oddpost' ), array( 'status' => 409 ) );
		}
		$send_id = (int) $state['id'];

		$rate = $this->send_store->consume_send_rate( $user_id );
		if ( is_wp_error( $rate ) ) {
			$this->send_store->mark_failed_before_handoff( $send_id, $rate->get_error_code() );
			return $rate;
		}

		// Re-resolve files at the last possible moment so stale paths never reach a mailer.
		$attachments = $this->preparer->validate_attachments( $prepared['attachmentIds'], $user_id );
		if ( is_wp_error( $attachments ) ) {
			$this->send_store->mark_failed_before_handoff( $send_id, $attachments->get_error_code() );
			return $attachments;
		}
		$prepared_manifest = wp_json_encode( $prepared['attachmentManifest'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		$current_manifest  = wp_json_encode( $attachments['manifest'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( ! is_string( $prepared_manifest ) || ! is_string( $current_manifest ) || ! hash_equals( $prepared_manifest, $current_manifest ) ) {
			$this->send_store->mark_failed_before_handoff( $send_id, 'attachment_changed' );
			return new WP_Error( 'oddpost_attachment_changed', __( 'An attachment changed after preparation. Review the final letter again before sending.', 'oddpost' ), array( 'status' => 409 ) );
		}
		$message = array(
			'to'              => $prepared['to'],
			'cc'              => $prepared['cc'],
			'bcc'             => $prepared['bcc'],
			'subject'         => $prepared['subject'],
			'html'            => $prepared['html'],
			'text'            => $prepared['text'],
			'attachmentPaths' => $attachments['paths'],
		);

		try {
			$sent = $this->mailer->send( $message, $connection );
		} catch ( Throwable $error ) {
			$sent = new WP_Error( 'oddpost_send_failed', __( 'The sending service did not confirm acceptance.', 'oddpost' ) );
		}
		if ( is_wp_error( $sent ) ) {
			$this->send_store->mark_uncertain( $send_id, $sent->get_error_code() );
			return $this->uncertain_error( $send_id );
		}

		$accepted = $this->send_store->mark_accepted( $send_id );
		if ( is_wp_error( $accepted ) ) {
			$this->send_store->mark_uncertain( $send_id, 'acceptance_record_failed' );
			return $this->uncertain_error( $send_id );
		}

		$sent_at = $accepted['accepted_at'];
		$canonical_input = array_merge(
			$input,
			array(
				'to'          => $prepared['to'],
				'cc'          => $prepared['cc'],
				'bcc'         => $prepared['bcc'],
				'subject'     => $prepared['subject'],
				'html'        => $prepared['html'],
				'text'        => $prepared['text'],
				'attachments' => $prepared['attachmentIds'],
			)
		);
		$draft = $this->store->save_draft( $canonical_input, $user_id );
		$draft_id = ! is_wp_error( $draft ) && ! empty( $draft['id'] ) ? (int) $draft['id'] : 0;
		if ( $draft_id ) {
			update_post_meta( $draft_id, '_oddpost_status', 'sent' );
			update_post_meta( $draft_id, '_oddpost_sent_at', $sent_at );
			$this->send_store->set_draft_id( $send_id, $draft_id );
		}

		return rest_ensure_response( $this->accepted_response( array( 'draft_id' => $draft_id, 'accepted_at' => $sent_at ), false ) );
	}

	/** @return string */
	private function request_hash( $prepared, $connection ) {
		$fingerprint = array(
			'provider'  => isset( $connection['provider'] ) ? (string) $connection['provider'] : '',
			'fromName'  => isset( $connection['fromName'] ) ? (string) $connection['fromName'] : '',
			'fromEmail' => isset( $connection['fromEmail'] ) ? strtolower( (string) $connection['fromEmail'] ) : '',
			'replyTo'   => isset( $connection['replyTo'] ) ? strtolower( (string) $connection['replyTo'] ) : '',
			'host'      => isset( $connection['host'] ) ? strtolower( (string) $connection['host'] ) : '',
			'port'      => isset( $connection['port'] ) ? (int) $connection['port'] : 0,
			'secure'    => isset( $connection['secure'] ) ? (string) $connection['secure'] : '',
			'username'  => isset( $connection['username'] ) ? strtolower( (string) $connection['username'] ) : '',
		);
		return hash( 'sha256', wp_json_encode( array( 'artifactHash' => $prepared['artifactHash'], 'connection' => $fingerprint ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
	}

	/** @return array */
	private function accepted_response( $row, $replayed ) {
		$draft_id = isset( $row['draft_id'] ) ? (int) $row['draft_id'] : 0;
		$accepted_at = isset( $row['accepted_at'] ) ? (string) $row['accepted_at'] : '';
		return array(
			'ok'        => true,
			'accepted'  => true,
			'replayed'  => (bool) $replayed,
			'copySaved' => 0 < $draft_id,
			'draftId'   => $draft_id,
			'sentAt'    => Oddpost_Store::gmt_mysql_to_rfc3339( $accepted_at ),
			'note'      => 0 < $draft_id
				? __( 'Your sending service accepted the message. This is not a delivery receipt.', 'oddpost' )
				: __( 'Your sending service accepted the message, but ODD Post could not save its local sent copy. This is not a delivery receipt.', 'oddpost' ),
		);
	}

	/** @return WP_Error */
	private function uncertain_error( $send_id = 0 ) {
		return new WP_Error(
			'oddpost_send_uncertain',
			__( 'Acceptance could not be confirmed. Do not retry automatically; check the sending account first, then explicitly choose to send a new copy.', 'oddpost' ),
			array( 'status' => 409, 'duplicateOf' => (int) $send_id, 'previousStatus' => 'uncertain' )
		);
	}
}
