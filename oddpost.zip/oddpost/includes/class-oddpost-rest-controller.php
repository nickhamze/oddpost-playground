<?php
/**
 * REST controller for the Oddpost native window.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_REST_Controller {
	/** @var Oddpost_Store */
	private $store;
	/** @var Oddpost_Mailer */
	private $mailer;

	public function __construct( $store, $mailer ) {
		$this->store  = $store;
		$this->mailer = $mailer;
	}

	public function register_routes() {
		$permission = array( $this, 'permissions_check' );
		register_rest_route( 'oddpost/v1', '/bootstrap', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'bootstrap' ), 'permission_callback' => $permission ) );
		register_rest_route( 'oddpost/v1', '/drafts', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'list_drafts' ), 'permission_callback' => $permission ),
			array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'save_draft' ), 'permission_callback' => $permission ),
		) );
		register_rest_route( 'oddpost/v1', '/drafts/(?P<id>\\d+)', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'get_draft' ), 'permission_callback' => $permission ),
			array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( $this, 'delete_draft' ), 'permission_callback' => $permission ),
		) );
		register_rest_route( 'oddpost/v1', '/connection', array(
			array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( $this, 'get_connection' ), 'permission_callback' => $permission ),
			array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'save_connection' ), 'permission_callback' => $permission ),
			array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( $this, 'delete_connection' ), 'permission_callback' => $permission ),
		) );
		register_rest_route( 'oddpost/v1', '/connection/test', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'test_connection' ), 'permission_callback' => $permission ) );
		register_rest_route( 'oddpost/v1', '/send', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( $this, 'send' ), 'permission_callback' => $permission ) );
	}

	public function permissions_check() {
		return current_user_can( 'edit_posts' );
	}

	public function bootstrap() {
		return rest_ensure_response( array(
			'drafts'     => $this->store->list_drafts( get_current_user_id() ),
			'connection' => $this->store->get_connection_summary( get_current_user_id() ),
			'providers'  => array_keys( Oddpost_Store::provider_presets() ),
		) );
	}

	public function list_drafts() {
		return rest_ensure_response( $this->store->list_drafts( get_current_user_id() ) );
	}

	public function get_draft( $request ) {
		$draft = $this->store->get_draft( absint( $request['id'] ), get_current_user_id() );
		return is_wp_error( $draft ) ? $draft : rest_ensure_response( $draft );
	}

	public function save_draft( $request ) {
		$draft = $this->store->save_draft( (array) $request->get_json_params(), get_current_user_id() );
		return is_wp_error( $draft ) ? $draft : rest_ensure_response( $draft );
	}

	public function delete_draft( $request ) {
		$deleted = $this->store->delete_draft( absint( $request['id'] ), get_current_user_id() );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}
		return rest_ensure_response( array( 'deleted' => (bool) $deleted ) );
	}

	public function get_connection() {
		return rest_ensure_response( $this->store->get_connection_summary( get_current_user_id() ) );
	}

	public function save_connection( $request ) {
		$connection = $this->store->save_connection( (array) $request->get_json_params(), get_current_user_id() );
		return is_wp_error( $connection ) ? $connection : rest_ensure_response( $connection );
	}

	public function delete_connection() {
		$this->store->delete_connection( get_current_user_id() );
		return rest_ensure_response( array( 'deleted' => true ) );
	}

	public function test_connection() {
		$connection = $this->store->get_connection( get_current_user_id() );
		if ( is_wp_error( $connection ) ) {
			return $connection;
		}
		$tested = $this->mailer->test_connection( $connection );
		if ( is_wp_error( $tested ) ) {
			return $tested;
		}
		return rest_ensure_response( array( 'ok' => true ) );
	}

	public function send( $request ) {
		$user_id = get_current_user_id();
		$input   = (array) $request->get_json_params();
		$token   = isset( $input['idempotencyKey'] ) ? sanitize_key( $input['idempotencyKey'] ) : '';
		if ( strlen( $token ) < 16 ) {
			return new WP_Error( 'oddpost_send_token_invalid', __( 'The send request is missing its safety token.', 'oddpost' ), array( 'status' => 400 ) );
		}

		$lock_key = 'oddpost_send_' . $user_id . '_' . md5( $token );
		if ( get_transient( $lock_key ) ) {
			return new WP_Error( 'oddpost_already_sent', __( 'This send request was already handled.', 'oddpost' ), array( 'status' => 409 ) );
		}

		$to  = $this->store->sanitize_address_list( isset( $input['to'] ) ? $input['to'] : array() );
		$cc  = $this->store->sanitize_address_list( isset( $input['cc'] ) ? $input['cc'] : array() );
		$bcc = $this->store->sanitize_address_list( isset( $input['bcc'] ) ? $input['bcc'] : array() );
		if ( empty( $to ) || count( array_unique( array_merge( $to, $cc, $bcc ) ) ) > Oddpost_Store::MAX_RECIPIENTS ) {
			return new WP_Error( 'oddpost_recipients_invalid', __( 'Add at least one recipient, with no more than 20 people total.', 'oddpost' ), array( 'status' => 400 ) );
		}
		$subject  = sanitize_text_field( isset( $input['subject'] ) ? $input['subject'] : '' );
		$raw_html = isset( $input['html'] ) ? (string) $input['html'] : '';
		if ( strlen( $raw_html ) > Oddpost_Store::MAX_HTML_BYTES ) {
			return new WP_Error( 'oddpost_message_too_large', __( 'The HTML version is too large to send safely.', 'oddpost' ), array( 'status' => 413 ) );
		}
		$html    = $this->store->sanitize_email_html( $raw_html );
		$text    = sanitize_textarea_field( isset( $input['text'] ) ? $input['text'] : '' );
		if ( '' === $subject || '' === trim( wp_strip_all_tags( $html ) ) || '' === $text ) {
			return new WP_Error( 'oddpost_message_incomplete', __( 'Subject, HTML, and plain-text content are required.', 'oddpost' ), array( 'status' => 400 ) );
		}

		$attachment_ids   = $this->store->sanitize_attachment_ids( isset( $input['attachments'] ) ? $input['attachments'] : array(), $user_id );
		$attachment_paths = array_filter( array_map( 'get_attached_file', $attachment_ids ) );
		$message          = array(
			'to'              => $to,
			'cc'              => $cc,
			'bcc'             => $bcc,
			'subject'         => $subject,
			'html'            => $html,
			'text'            => $text,
			'attachmentPaths' => $attachment_paths,
		);
		$connection = $this->store->get_connection( $user_id );
		if ( is_wp_error( $connection ) ) {
			return $connection;
		}

		set_transient( $lock_key, 'sending', 10 * MINUTE_IN_SECONDS );
		$sent = $this->mailer->send( $message, $connection );
		if ( is_wp_error( $sent ) ) {
			delete_transient( $lock_key );
			return $sent;
		}
		set_transient( $lock_key, 'sent', DAY_IN_SECONDS );

		$draft = $this->store->save_draft( $input, $user_id );
		if ( ! is_wp_error( $draft ) && ! empty( $draft['id'] ) ) {
			update_post_meta( $draft['id'], '_oddpost_status', 'sent' );
			update_post_meta( $draft['id'], '_oddpost_sent_at', current_time( 'mysql', true ) );
			update_post_meta( $draft['id'], '_oddpost_send_token', $token );
		}

		return rest_ensure_response( array(
			'ok'       => true,
			'accepted' => true,
			'draftId'  => ! is_wp_error( $draft ) && ! empty( $draft['id'] ) ? (int) $draft['id'] : 0,
			'sentAt'   => current_time( 'mysql', true ),
			'note'     => __( 'Your sending service accepted the message. This is not a delivery receipt.', 'oddpost' ),
		) );
	}
}
