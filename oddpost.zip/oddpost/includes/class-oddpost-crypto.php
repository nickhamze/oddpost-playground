<?php
/**
 * Small authenticated-encryption helper for user-owned SMTP secrets.
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

final class Oddpost_Crypto {
	/**
	 * Encrypt a value using a key derived from the site's auth salt.
	 *
	 * @param string $plaintext Value to encrypt.
	 * @return string|WP_Error Encoded envelope or error.
	 */
	public static function encrypt( $plaintext ) {
		if ( '' === $plaintext ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return new WP_Error( 'oddpost_crypto_unavailable', __( 'OpenSSL is required to save an email password.', 'oddpost' ) );
		}

		$key        = hash( 'sha256', wp_salt( 'auth' ) . '|oddpost|v1', true );
		$iv         = random_bytes( 12 );
		$tag        = '';
		$ciphertext = openssl_encrypt( $plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'oddpost:v1', 16 );
		if ( false === $ciphertext ) {
			return new WP_Error( 'oddpost_crypto_failed', __( 'The email password could not be encrypted.', 'oddpost' ) );
		}

		return base64_encode( $iv . $tag . $ciphertext );
	}

	/**
	 * Decrypt a stored envelope.
	 *
	 * @param string $envelope Encoded envelope.
	 * @return string|WP_Error Plaintext or error.
	 */
	public static function decrypt( $envelope ) {
		if ( '' === $envelope ) {
			return '';
		}
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return new WP_Error( 'oddpost_crypto_unavailable', __( 'OpenSSL is required to use the saved email password.', 'oddpost' ) );
		}

		$decoded = base64_decode( $envelope, true );
		if ( false === $decoded || strlen( $decoded ) < 29 ) {
			return new WP_Error( 'oddpost_crypto_invalid', __( 'The saved email password is invalid. Reconnect the account.', 'oddpost' ) );
		}

		$key        = hash( 'sha256', wp_salt( 'auth' ) . '|oddpost|v1', true );
		$iv         = substr( $decoded, 0, 12 );
		$tag        = substr( $decoded, 12, 16 );
		$ciphertext = substr( $decoded, 28 );
		$plaintext  = openssl_decrypt( $ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'oddpost:v1' );

		if ( false === $plaintext ) {
			return new WP_Error( 'oddpost_crypto_invalid', __( 'The saved email password could not be opened. Reconnect the account.', 'oddpost' ) );
		}

		return $plaintext;
	}
}

