<?php
/**
 * Plugin Name:       ODD Post
 * Plugin URI:        https://openstation.org/oddpost
 * Description:       Beautiful one-off personal correspondence, sent from an OpenStation desktop.
 * Version:           0.2.3
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  desktop-mode
 * Author:            OpenStation
 * License:           GPL-2.0-or-later
 * Text Domain:       oddpost
 *
 * @package Oddpost
 */

defined( 'ABSPATH' ) || exit;

define( 'ODDPOST_VERSION', '0.2.3' );
define( 'ODDPOST_SCHEMA_VERSION', '2' );
define( 'ODDPOST_FILE', __FILE__ );
define( 'ODDPOST_DIR', plugin_dir_path( __FILE__ ) );
define( 'ODDPOST_URL', plugin_dir_url( __FILE__ ) );

require_once ODDPOST_DIR . 'includes/class-oddpost-crypto.php';
require_once ODDPOST_DIR . 'includes/class-oddpost-store.php';
require_once ODDPOST_DIR . 'includes/class-oddpost-message-preparer.php';
require_once ODDPOST_DIR . 'includes/class-oddpost-mailer.php';
require_once ODDPOST_DIR . 'includes/class-oddpost-send-store.php';
require_once ODDPOST_DIR . 'includes/class-oddpost-rest-controller.php';

/**
 * Install delivery safety state and grant sending only to administrators.
 *
 * Runs both on activation and on normal load so already-active local installs
 * receive the migration. Data and capabilities are intentionally retained on
 * deactivation.
 *
 * @return true|WP_Error
 */
function oddpost_maybe_upgrade() {
	if ( ODDPOST_SCHEMA_VERSION === (string) get_option( 'oddpost_schema_version', '0' ) ) {
		return true;
	}
	$installed = Oddpost_Send_Store::install_schema();
	if ( is_wp_error( $installed ) ) {
		return $installed;
	}
	$administrator = get_role( 'administrator' );
	if ( $administrator ) {
		$administrator->add_cap( 'oddpost_send_mail' );
	}
	update_option( 'oddpost_schema_version', ODDPOST_SCHEMA_VERSION, false );
	return true;
}
register_activation_hook( ODDPOST_FILE, 'oddpost_maybe_upgrade' );
add_action( 'plugins_loaded', 'oddpost_maybe_upgrade', 5 );

/**
 * Register ODD Post's private, revisioned letter store.
 */
function oddpost_register_post_type() {
	register_post_type(
		'oddpost_letter',
		array(
			'labels'       => array(
				'name'          => __( 'ODD Post letters', 'oddpost' ),
				'singular_name' => __( 'ODD Post letter', 'oddpost' ),
			),
			'public'       => false,
			'show_ui'      => false,
			'show_in_rest' => false,
			'supports'     => array( 'title', 'editor', 'author', 'revisions' ),
			'map_meta_cap' => true,
			'capability_type' => 'post',
		)
	);
}
add_action( 'init', 'oddpost_register_post_type', 10 );

/**
 * Register the REST surface used by the native OpenStation window.
 */
function oddpost_register_rest_routes() {
	$controller = new Oddpost_REST_Controller( new Oddpost_Store(), new Oddpost_Mailer(), null, new Oddpost_Send_Store() );
	$controller->register_routes();
}
add_action( 'rest_api_init', 'oddpost_register_rest_routes' );

/**
 * Register the bundle handles. OpenStation decides when to enqueue them.
 */
function oddpost_register_assets() {
	wp_register_script(
		'oddpost-app',
		ODDPOST_URL . 'build/oddpost.js',
		array( 'openstation' ),
		ODDPOST_VERSION,
		true
	);

	wp_register_style(
		'oddpost-app',
		ODDPOST_URL . 'build/oddpost.css',
		array(),
		ODDPOST_VERSION
	);
}
add_action( 'admin_enqueue_scripts', 'oddpost_register_assets', 5 );

/**
 * Print the native-window mount point OpenStation clones per window.
 */
function oddpost_render_window_template() {
	?>
	<div class="oddpost-mount" data-oddpost-root></div>
	<?php
}

/**
 * Register the OpenStation-native app and desktop launcher.
 */
function oddpost_register_openstation_app() {
	if ( ! function_exists( 'openstation_register_window' ) || ! function_exists( 'openstation_register_icon' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}

	$current_user = wp_get_current_user();
	$avatar_url   = get_avatar_url( $current_user->ID, array( 'size' => 96 ) );
	$config       = array(
		'restRoot'       => esc_url_raw( rest_url( 'oddpost/v1/' ) ),
		'mediaUrl'       => esc_url_raw( rest_url( 'wp/v2/media' ) ),
		'currentUser'    => array(
			'id'     => (int) $current_user->ID,
			'name'   => $current_user->display_name,
			'email'  => $current_user->user_email,
			'avatar' => $avatar_url ? esc_url_raw( $avatar_url ) : '',
		),
		'siteName'       => get_bloginfo( 'name' ),
		'publicSiteUrl'  => esc_url_raw( home_url( '/' ) ),
		'maxRecipients'  => Oddpost_Store::MAX_RECIPIENTS,
		'maxHtmlBytes'   => Oddpost_Store::MAX_HTML_BYTES,
		'capabilities'   => array(
			'uploadFiles' => current_user_can( 'upload_files' ),
			'canSend'     => current_user_can( 'oddpost_send_mail' ),
		),
	);

	$window = openstation_register_window(
		'oddpost',
		array(
			'title'        => __( 'ODD Post', 'oddpost' ),
			'icon'         => 'dashicons-email-alt2',
			'template'     => 'oddpost_render_window_template',
			'script'       => 'oddpost-app',
			'style'        => 'oddpost-app',
			'width'        => 1180,
			'height'       => 780,
			'min_width'    => 296,
			'min_height'   => 400,
			'placement'    => 'dock',
			'capabilities' => array( 'edit_posts' ),
			'autofocus'    => false,
			'config'       => $config,
		)
	);

	if ( is_wp_error( $window ) ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( '[oddpost] Window registration failed: ' . $window->get_error_message() );
		return;
	}

	$icon_svg = is_readable( ODDPOST_DIR . 'assets/oddpost-icon.svg' )
		? file_get_contents( ODDPOST_DIR . 'assets/oddpost-icon.svg' )
		: '';
	$icon     = openstation_register_icon(
		'oddpost',
		array(
			'title'        => __( 'ODD Post', 'oddpost' ),
			'icon'         => 'dashicons-email-alt2',
			'icon_svg'     => $icon_svg,
			'window'       => 'oddpost',
			'position'     => 22,
			'capabilities' => array( 'edit_posts' ),
		)
	);

	if ( is_wp_error( $icon ) ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( '[oddpost] Desktop icon registration failed: ' . $icon->get_error_message() );
	}
}
add_action( 'init', 'oddpost_register_openstation_app', 30 );
